Backup of lib/home.dart prior to padding edits.

