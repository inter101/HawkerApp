Backup of lib/settings.dart prior to padding edits.

