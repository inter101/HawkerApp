import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/custsignin.dart';
import 'package:flutter_application_1/Real_Mad_project/hawkersignin.dart';


const kOrange = Color(0xFFF4791F);

const _roles = [
  (
    icon: Icons.person_outline,
    title: "I'm a Customer",
    subtitle: 'Browse stalls and place orders',
  ),
  (
    icon: Icons.storefront_outlined,
    title: "I'm a Hawker",
    subtitle: 'Manage your stall and incoming orders',
  ),
];

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: kOrange,
      padding: const EdgeInsets.symmetric(vertical: 60),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              color: Colors.white,
              
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(Icons.restaurant, color: kOrange, size: 44),
          ),
          const SizedBox(height: 20),
          const Text(
            'HawkerGo',
            style: TextStyle(
              fontSize: 34,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Singapore's hawker food, simplified",
            style: TextStyle(fontSize: 16, color: Colors.white70),
          ),
        ],
      ),
    );
  }
}

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const _Header(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                Text(
                  'How are you using HawkerGo today?',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 20, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 24),
                for (final role in _roles)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: const BorderSide(color: Color(0xFFF3D9BC)),
                      ),
                      leading: CircleAvatar(
                        radius: 28,
                        backgroundColor: kOrange.withOpacity(0.1),
                        child: Icon(role.icon, color: kOrange),
                      ),
                      title: Text(
                        role.title,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(role.subtitle),
                      trailing: const Icon(
                        Icons.arrow_forward,
                        color: Colors.grey,
                      ),
                      onTap: () {
                        final screen = role.title == "I'm a Customer"
                            ? const CustSignInScreen()
                            : const HawkerSignInScreen();
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => screen),
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 12),
                Text(
                  'By continuing you agree to our Terms & Privacy Policy',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade400),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
