import 'dart:math';
// ignore: depend_on_referenced_packages
import 'package:shared_preferences/shared_preferences.dart';

/// Temporary stand-in for a real logged-in customer ID.
///
/// TODO(Kaviya): Once your teammate's login is ready and you know how his
/// customer records are keyed (e.g. a Firebase Auth uid, or a custom doc ID
/// like the "hawker_005" style docs you showed me), replace the body of
/// `customerId()` below with however you get the real logged-in customer's
/// ID (e.g. `FirebaseAuth.instance.currentUser!.uid`).
///
/// Everything that calls `LocalIdentity.customerId()` elsewhere in the app
/// does NOT need to change — they'll automatically start using the real ID
/// the moment this method returns it instead. That's the whole point of
/// wrapping it here instead of scattering "TODO get real id" everywhere.
class LocalIdentity {
  LocalIdentity._();

  static const _prefsKey = 'temp_customer_id';
  static String? _cached;

  /// Returns a stable ID for "this device" so ratings/reviews can be tied
  /// to a person and updated later, even before real login exists.
  ///
  /// The same ID is returned every time on the same device (it's saved to
  /// local storage), so re-submitting a rating updates the same record
  /// instead of creating a new one.
  static Future<String> customerId() async {
    if (_cached != null) return _cached!;

    final prefs = await SharedPreferences.getInstance();
    String? id = prefs.getString(_prefsKey);

    if (id == null) {
      id = _generateId();
      await prefs.setString(_prefsKey, id);
    }

    _cached = id;
    return id;
  }

  static String _generateId() {
    final rand = Random();
    return 'guest_${DateTime.now().millisecondsSinceEpoch}_${rand.nextInt(999999)}';
  }
}