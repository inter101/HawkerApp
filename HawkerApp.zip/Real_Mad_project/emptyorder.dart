import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';


class empty extends StatefulWidget {
  const empty({super.key});

  @override
  State<empty> createState() => _emptyState();
}

class _emptyState extends State<empty> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      alignment: Alignment.center,
      child: Column(
        children: [
          SizedBox(height: 75),

          Container(
            width: 65,
            height: 65,
            decoration: const BoxDecoration(
              color: Color(0xFFFDE8D6),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.shopping_bag_outlined, color: kOrange, size: 40),
          ),
          SizedBox(height: 20),
          Container(child: Text('All Clear!')),
          SizedBox(height: 10),
          Container(child: Text('No pending order right now')),
        ],
      ),
    );
  }
}
