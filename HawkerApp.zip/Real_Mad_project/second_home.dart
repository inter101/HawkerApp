import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_application_1/Real_Mad_project/app_bottom_nav.dart';
import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';
import 'package:flutter_application_1/Real_Mad_project/notification_service.dart';
import 'package:flutter_application_1/Real_Mad_project/points_badge.dart';

class SecondHome extends StatefulWidget {
  const SecondHome({super.key});

  @override
  State<SecondHome> createState() => _SecondHomeState();
}

class _SecondHomeState extends State<SecondHome> {
  final TextEditingController _searchController = TextEditingController();

  String _query = '';

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _hawkerSubscription;

  bool _hasUnreadNotification = true;

  late String _notificationMessage;

  // ------------------------------------------------------------
  // FALLBACK DISHES
  // ------------------------------------------------------------

  List<Map<String, dynamic>> _allDishes = [
    {
      'stallName': 'Noodle Story',
      'dishName': 'Laska',
      'price': r'$6.00',
      'unitNo': '#01-05',
      'status': 'Available',
      'statusColor': Colors.green,
      'statusBg': Colors.greenAccent,
      'stars': 4,
      'imageUrl': 'smt.png',
    },
    {
      'stallName': 'ALIFF NASI LEMAK',
      'dishName': 'Nasi Lemak',
      'price': r'$14.00',
      'unitNo': '#04-19',
      'status': 'out of stock',
      'statusColor': Colors.red,
      'statusBg': Colors.redAccent,
      'stars': 2,
      'imageUrl': 'nasilemak.png',
    },
    {
      'stallName': 'Maxwell Hainanese Chicken Rice',
      'dishName': 'Chicken Rice',
      'price': r'$4.50',
      'unitNo': '#18-06',
      'status': 'Available',
      'statusColor': Colors.green,
      'statusBg': Colors.greenAccent,
      'stars': 1,
      'imageUrl': 'chickenrice.png',
    },
  ];

  // ------------------------------------------------------------
  // SEARCH
  // ------------------------------------------------------------

  List<Map<String, dynamic>> get _filteredDishes {
    if (_query.isEmpty) {
      return _allDishes;
    }

    final lower = _query.toLowerCase();

    return _allDishes.where((dish) {
      final stallName = (dish['stallName'] as String).toLowerCase();

      final dishName = (dish['dishName'] as String).toLowerCase();

      return stallName.contains(lower) || dishName.contains(lower);
    }).toList();
  }

  // ------------------------------------------------------------
  // INIT
  // ------------------------------------------------------------

  @override
  void initState() {
    super.initState();

    _notificationMessage = _generateNotificationMessage();

    _loadHomepageDishesFromFirestore();

    _watchHawkerCollection();
  }

  @override
  void dispose() {
    _hawkerSubscription?.cancel();
    _searchController.dispose();

    super.dispose();
  }

  // ------------------------------------------------------------
  // WATCH HAWKER COLLECTION
  // ------------------------------------------------------------

  void _watchHawkerCollection() {
    _hawkerSubscription?.cancel();

    _hawkerSubscription = FirebaseFirestore.instance
        .collection('Hawker')
        .snapshots()
        .listen((snapshot) {
          if (!mounted) return;

          _loadHomepageDishesFromFirestore();
        });
  }

  // ------------------------------------------------------------
  // NOTIFICATION
  // ------------------------------------------------------------

  String _generateNotificationMessage() {
    return 'Your order is ready.';
  }

  // ------------------------------------------------------------
  // CONVERT TO DOUBLE
  // ------------------------------------------------------------

  double _toDouble(dynamic value, {double fallback = 0}) {
    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value?.toString() ?? '') ?? fallback;
  }

  // ------------------------------------------------------------
  // CONVERT TO BOOL
  // ------------------------------------------------------------

  bool _toBool(dynamic value, {bool fallback = true}) {
    if (value is bool) {
      return value;
    }

    final text = value?.toString().trim().toLowerCase() ?? '';

    if (text == 'true' || text == '1' || text == 'yes' || text == 'open') {
      return true;
    }

    if (text == 'false' || text == '0' || text == 'no' || text == 'closed') {
      return false;
    }

    return fallback;
  }

  // ------------------------------------------------------------
  // LOAD DISHES FROM FIRESTORE
  //
  // Firestore:
  //
  // Image: "smt.png"
  //
  // Flutter:
  //
  // assets/images/smt.png
  // ------------------------------------------------------------

  Future<void> _loadHomepageDishesFromFirestore() async {
    try {
      final localFallback = _allDishes
          .map((dish) => Map<String, dynamic>.from(dish))
          .toList();

      final hawkerSnapshot = await FirebaseFirestore.instance
          .collection('Hawker')
          .get();

      if (hawkerSnapshot.docs.isEmpty) {
        return;
      }

      final List<Map<String, dynamic>> firebaseDishes = [];

      // ----------------------------------------------------------
      // LOOP THROUGH EACH HAWKER
      // ----------------------------------------------------------

      for (final hawkerDoc in hawkerSnapshot.docs) {
        final hawkerDocId = hawkerDoc.id;

        final rootData = hawkerDoc.data();

        final profileRef = FirebaseFirestore.instance
            .collection('Hawker')
            .doc(hawkerDocId)
            .collection('profile')
            .doc('Profile');

        // Get profile
        final profileSnapshot = await profileRef.get();

        // Get menu
        final menuSnapshot = await profileRef.collection('Menu').get();

        if (menuSnapshot.docs.isEmpty) {
          continue;
        }

        final profileData = profileSnapshot.data() ?? <String, dynamic>{};

        // --------------------------------------------------------
        // STALL NAME
        // --------------------------------------------------------

        final stallName =
            (profileData['stallname'] ??
                    rootData['stallname'] ??
                    rootData['name'] ??
                    hawkerDocId)
                .toString();

        // --------------------------------------------------------
        // STALL NUMBER
        // --------------------------------------------------------

        final stallNum =
            (profileData['stallnum'] ??
                    rootData['stallnum'] ??
                    rootData['unitNo'] ??
                    '#00-00')
                .toString();

        // --------------------------------------------------------
        // STALL STATUS
        // --------------------------------------------------------

        final bool stallOpen = _toBool(
          profileData['status'] ?? rootData['status'],
          fallback: true,
        );

        // --------------------------------------------------------
        // LOOP THROUGH MENU
        // --------------------------------------------------------

        for (final menuDoc in menuSnapshot.docs) {
          final data = menuDoc.data();

          // ------------------------------------------------------
          // PRICE
          // ------------------------------------------------------

          final double price = _toDouble(data['Price'] ?? data['price']);

          // ------------------------------------------------------
          // STOCK
          // ------------------------------------------------------

          final bool inStock = _toBool(
            data['Stock'] ?? data['available'],
            fallback: true,
          );

          final bool available = stallOpen && inStock;

          // ------------------------------------------------------
          // IMAGE
          //
          // Firestore stores:
          //
          // Image: "smt.png"
          //
          // We keep ONLY the filename here.
          // ------------------------------------------------------

          final String imageName = (data['Image'] ?? data['imageUrl'] ?? '')
              .toString()
              .trim();

          // ------------------------------------------------------
          // RATING
          // ------------------------------------------------------

          final int stars = _toDouble(
            data['stars'] ?? data['rating'],
            fallback: 4,
          ).round().clamp(0, 5);

          // ------------------------------------------------------
          // ADD DISH
          // ------------------------------------------------------

          firebaseDishes.add(<String, dynamic>{
            'stallDocId': hawkerDocId,

            'stallName': stallName,

            'dishName': (data['DishName'] ?? data['name'] ?? 'Unnamed Dish')
                .toString(),

            'price': '\$${price.toStringAsFixed(2)}',

            'unitNo': stallNum,

            'status': available ? 'Available' : 'out of stock',

            'statusColor': available ? Colors.green : Colors.red,

            'statusBg': available
                ? Colors.greenAccent
                : Colors.redAccent.shade100,

            'stars': stars,

            // IMPORTANT:
            // Store only the filename.
            'imageUrl': imageName,
          });
        }
      }

      if (firebaseDishes.isEmpty || !mounted) {
        return;
      }

      // ----------------------------------------------------------
      // MERGE FIRESTORE + FALLBACK
      // ----------------------------------------------------------

      setState(() {
        final seen = <String>{};

        String dishKey(Map<String, dynamic> dish) {
          final stall = (dish['stallName'] ?? '')
              .toString()
              .trim()
              .toLowerCase();

          final name = (dish['dishName'] ?? '').toString().trim().toLowerCase();

          return '$stall|$name';
        }

        final merged = <Map<String, dynamic>>[];

        // Add fallback dishes first
        for (final dish in localFallback) {
          final key = dishKey(dish);

          if (seen.add(key)) {
            merged.add(dish);
          }
        }

        // Add Firestore dishes
        for (final dish in firebaseDishes) {
          final key = dishKey(dish);

          if (seen.add(key)) {
            merged.add(dish);
          }
        }

        _allDishes = merged;
      });
    } catch (e) {
      debugPrint('Error loading homepage dishes: $e');

      // Keep fallback dishes
    }
  }

  // ------------------------------------------------------------
  // NOTIFICATION POPUP
  // ------------------------------------------------------------

  Future<void> _showNotificationPopup(BuildContext context) async {
    if (_hasUnreadNotification) {
      setState(() {
        _hasUnreadNotification = false;
      });
    }

    NotificationService.instance.showOrderReadyNotification(
      dinein: false,
      message: _notificationMessage,
    );

    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text('Notification'),
          content: Text(
            _notificationMessage,
            style: const TextStyle(fontSize: 16, color: Colors.black87),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  // ------------------------------------------------------------
  // BUILD
  // ------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 110),

        child: Column(
          children: [
            // ====================================================
            // HEADER
            // ====================================================
            Stack(
              clipBehavior: Clip.none,

              children: [
                SizedBox(
                  width: double.infinity,

                  child: Container(
                    padding: const EdgeInsets.fromLTRB(20, 60, 20, 25),

                    decoration: const BoxDecoration(
                      color: Color.fromRGBO(243, 129, 27, 0.9),

                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(35),
                        bottomRight: Radius.circular(35),
                      ),
                    ),

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        const SizedBox(height: 20),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,

                          children: [
                            const Text(
                              'HawkerGo',
                              style: TextStyle(
                                fontSize: 45,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),

                            Container(
                              decoration: BoxDecoration(
                                color: _hasUnreadNotification
                                    ? Colors.white
                                    : const Color.fromRGBO(255, 255, 255, 0.3),
                                shape: BoxShape.circle,
                              ),

                              child: IconButton(
                                icon: const Icon(
                                  Icons.notifications_none,
                                  color: Colors.black54,
                                ),

                                onPressed: () =>
                                    _showNotificationPopup(context),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 10),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,

                          children: const [
                            Expanded(
                              child: Text(
                                'Welcome Back ! Hungry for something\nGood ?',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,

                                style: TextStyle(
                                  fontSize: 18,
                                  color: Color.fromRGBO(255, 255, 255, 0.9),
                                ),
                              ),
                            ),

                            SizedBox(width: 10),

                            PointsBadge(onDark: true),
                          ],
                        ),

                        const SizedBox(height: 18),

                        Builder(
                          builder: (context) {
                            final customer = CustomerService.instance.current;

                            if (customer == null) {
                              return const SizedBox.shrink();
                            }

                            return Container(
                              padding: const EdgeInsets.all(14),

                              decoration: BoxDecoration(
                                color: const Color.fromRGBO(
                                  255,
                                  255,
                                  255,
                                  0.15,
                                ),

                                borderRadius: BorderRadius.circular(20),
                              ),

                              child: Row(
                                children: [
                                  const CircleAvatar(
                                    radius: 26,
                                    backgroundColor: Colors.white,

                                    child: Icon(
                                      Icons.person,
                                      color: Colors.black54,
                                      size: 28,
                                    ),
                                  ),

                                  const SizedBox(width: 14),

                                  Expanded(
                                    child: Text(
                                      'Hi, ${customer.name}',

                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                // ==================================================
                // SEARCH BAR
                // ==================================================
                Positioned(
                  left: 20,
                  right: 20,
                  bottom: -25,

                  child: Container(
                    height: 55,

                    decoration: BoxDecoration(
                      color: Colors.white,

                      borderRadius: BorderRadius.circular(30),

                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),

                    child: TextField(
                      controller: _searchController,

                      onChanged: (value) {
                        setState(() {
                          _query = value;
                        });
                      },

                      decoration: const InputDecoration(
                        hintText: 'Search for Dishes ...',

                        hintStyle: TextStyle(color: Colors.grey, fontSize: 16),

                        prefixIcon: Icon(
                          Icons.search,
                          color: Colors.black,
                          size: 24,
                        ),

                        border: InputBorder.none,

                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 15,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 45),

            // ====================================================
            // MOST POPULAR
            // ====================================================
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),

              child: Align(
                alignment: Alignment.centerLeft,

                child: const Text(
                  'Most popular :',

                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 15),

            // ====================================================
            // DISH LIST
            // ====================================================
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),

              child: Column(
                children: [
                  if (_filteredDishes.isEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 40),

                      alignment: Alignment.center,

                      child: const Text(
                        'No dishes match your search.',

                        style: TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    )
                  else
                    ..._filteredDishes.map((dish) {
                      return Column(
                        children: [
                          _buildDishCard(
                            context,

                            stallDocId: (dish['stallDocId'] ?? '').toString(),

                            stallName: dish['stallName'] as String,

                            dishName: dish['dishName'] as String,

                            price: dish['price'] as String,

                            unitNo: dish['unitNo'] as String,

                            status: dish['status'] as String,

                            statusColor: dish['statusColor'] as Color,

                            statusBg: dish['statusBg'] as Color,

                            stars: dish['stars'] as int,

                            imageUrl: dish['imageUrl'] as String,
                          ),

                          const SizedBox(height: 15),
                        ],
                      );
                    }),

                  const SizedBox(height: 15),
                ],
              ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: buildAppBottomNav(context, 0),
    );
  }

  // ============================================================
  // DISH CARD
  // ============================================================

  Widget _buildDishCard(
    BuildContext context, {
    required String stallDocId,
    required String stallName,
    required String dishName,
    required String price,
    required String unitNo,
    required String status,
    required Color statusColor,
    required Color statusBg,
    required int stars,
    required String imageUrl,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius: BorderRadius.circular(20),

        border: Border.all(color: Colors.blue.shade200, width: 1.5),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),

      child: Row(
        children: [
          // ======================================================
          // IMAGE
          // ======================================================
          ClipRRect(
            borderRadius: BorderRadius.circular(15),

            child: imageUrl.isEmpty
                ? Container(
                    width: 75,
                    height: 75,
                    color: Colors.grey.shade200,
                    child: const Icon(Icons.image, color: Colors.grey),
                  )
                : Image.asset(
                    'assets/images used/$imageUrl',

                    width: 75,
                    height: 75,

                    fit: BoxFit.cover,

                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        width: 75,
                        height: 75,
                        color: Colors.grey.shade200,
                        child: const Icon(
                          Icons.broken_image,
                          color: Colors.grey,
                        ),
                      );
                    },
                  ),
          ),

          const SizedBox(width: 15),

          // ======================================================
          // DISH INFORMATION
          // ======================================================
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  stallName.toUpperCase(),

                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Colors.orange.shade800,
                  ),

                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),

                const SizedBox(height: 2),

                Text(
                  dishName,

                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),

                const SizedBox(height: 4),

                Row(
                  children: [
                    Text(
                      price,

                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey,
                      ),
                    ),

                    const SizedBox(width: 8),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),

                      decoration: BoxDecoration(
                        color: Colors.grey.shade200,

                        borderRadius: BorderRadius.circular(4),
                      ),

                      child: Text(
                        unitNo,

                        style: const TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 6),

                Row(
                  children: [
                    Row(
                      children: List.generate(5, (index) {
                        return Icon(
                          index < stars ? Icons.star : Icons.star_border,

                          size: 14,

                          color: Colors.amber,
                        );
                      }),
                    ),

                    const SizedBox(width: 10),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),

                      decoration: BoxDecoration(
                        color: statusBg,

                        borderRadius: BorderRadius.circular(10),
                      ),

                      child: Text(
                        status,

                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: statusColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ======================================================
          // ADD TO CART BUTTON
          // ======================================================
          Builder(
            builder: (context) {
              final available = status.toLowerCase() == 'available';

              return Container(
                decoration: BoxDecoration(
                  color: Colors.orange.shade100,
                  shape: BoxShape.circle,
                ),

                child: IconButton(
                  icon: Icon(
                    Icons.add,

                    color: available ? Colors.black87 : Colors.grey.shade400,
                  ),

                  onPressed: available
                      ? () {
                          final dishPrice =
                              double.tryParse(
                                price.replaceAll(RegExp(r'[^0-9.]'), ''),
                              ) ??
                              0;

                          try {
                            CartService.instance.addItem(
                              CartItem(
                                id: '$stallName|$dishName',

                                name: dishName,

                                stall: stallName,

                                stallDocId: stallDocId,

                                price: dishPrice,

                                // Picture filename
                                // is not needed by
                                // CartService for now.
                                available: true,
                              ),
                            );

                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('$dishName added to cart'),
                                duration: const Duration(milliseconds: 800),
                              ),
                            );
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(e.toString())),
                            );
                          }
                        }
                      : null,
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
