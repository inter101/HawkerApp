import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';

class CartItem {
  CartItem({
    required this.id,
    required this.name,
    required this.stall,
    this.stallDocId = '',
    required this.price,
    this.quantity = 1,
    this.imageUrl,
    this.available = true,
  });

  final String id;
  final String name;
  final String stall;
  final String stallDocId;
  final double price;
  final String? imageUrl;

  int quantity;

  final bool available;

  double get total => price * quantity;
}

class CartOrder {
  CartOrder({
    required this.orderId,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.date,
    required this.dinein,
    required this.dishNames,
    required this.stallName,
    required this.stallDocId,
    this.stallNumber = '',
    this.orderNumber = 0,
    this.quantity = 0,
    this.pointsEarned = 0,
    this.status = 'preparing',
    Map<String, int>? dishRatings,
    this.comment = '',
  }) : dishRatings = dishRatings ?? {};

  final String orderId;

  final String title;

  final String subtitle;

  final String amount;

  final DateTime date;

  final bool dinein;

  final List<String> dishNames;

  final String stallName;

  final String stallDocId;

  final String stallNumber;

  final int orderNumber;

  final int quantity;

  final int pointsEarned;

  String status;

  Map<String, int> dishRatings;

  String comment;

  bool get hasRated => dishRatings.values.any((stars) => stars > 0);

  static const Duration standardPrepTime = Duration(minutes: 15);

  DateTime get estimatedReadyTime => date.add(standardPrepTime);

  bool get isServed => status == 'served';
}

class CartService with ChangeNotifier {
  CartService._();

  static final CartService instance = CartService._();

  final List<CartItem> _items = [];

  final List<CartOrder> orders = [];

  CartOrder? _recentOrder;

  List<CartItem> get items => List.unmodifiable(_items);

  CartOrder? get recentOrder => _recentOrder;



  static const int pointsPerDollar = 5;

  int _totalPoints = 0;

  int get totalPoints =>
      CustomerService.instance.current?.points ?? _totalPoints;

  static const double takeoutFee = 0.50;

  double discountAmount = 0.0;

  int redeemedPoints = 0;

  double get totalAmount {
    return _items.fold(0, (double total, CartItem item) => total + item.total);
  }

  int get availablePoints => totalPoints;

  bool get isPointsRedeemed => redeemedPoints > 0;

  bool get canRedeemPoints =>
      !isEmpty && !isPointsRedeemed && availablePoints >= 50;

  double get pointsDollarValue => availablePoints * 0.02;

  int get pointsNeededToRedeem => 50;

  double get maxDiscountFromPoints => min(pointsDollarValue, totalAmount);

  double _discountFromPoints(int points) => points * 0.02;

  String get totalAmountLabel => '\$${totalAmount.toStringAsFixed(2)}';

  double totalDue({required bool dineIn}) {
    if (_items.isEmpty) {
      return 0;
    }

    final fee = dineIn ? 0.0 : takeoutFee;

    final result = totalAmount + fee - discountAmount;

    return result < 0 ? 0 : result;
  }

  String totalDueLabel({required bool dineIn}) {
    return '\$${totalDue(dineIn: dineIn).toStringAsFixed(2)}';
  }



  void addItem(CartItem item) {
    if (!item.available) {
      throw Exception('Item is out of stock');
    }

    final existingIndex = _items.indexWhere((element) => element.id == item.id);

    if (existingIndex >= 0) {
      _items[existingIndex].quantity += 1;
    } else {
      _items.add(item);
    }

    notifyListeners();
  }

  void increment(CartItem item) {
    final index = _items.indexWhere((element) => element.id == item.id);

    if (index >= 0) {
      _items[index].quantity += 1;

      notifyListeners();
    }
  }

  void decrement(CartItem item) {
    final index = _items.indexWhere((element) => element.id == item.id);

    if (index >= 0) {
      final current = _items[index];

      if (current.quantity > 1) {
        current.quantity -= 1;
      } else {
        _items.removeAt(index);
      }

      notifyListeners();
    }
  }

  void removeItem(CartItem item) {
    _items.removeWhere((element) => element.id == item.id);

    notifyListeners();
  }

  void clearCart() {
    _items.clear();

    discountAmount = 0.0;

    redeemedPoints = 0;

    notifyListeners();
  }

  bool get isEmpty => _items.isEmpty;

  int get itemCount {
    return _items.fold(0, (current, item) => current + item.quantity);
  }

  bool _isServedFromRaw(dynamic raw) {
    if (raw is bool) {
      return raw;
    }

    if (raw is num) {
      return raw > 0;
    }

    final value = raw?.toString().trim().toLowerCase() ?? '';

    return value == 'served' ||
        value == 'done' ||
        value == 'completed' ||
        value == 'complete' ||
        value == 'true';
  }

  String _normalizeOrderStatus(Map<String, dynamic> data) {
    final dynamic raw =
        data['status'] ??
        data['orderStatus'] ??
        data['served'] ??
        data['done'] ??
        data['statusH'];

    return _isServedFromRaw(raw) ? 'served' : 'preparing';
  }


  Future<void> completeOrder({
    required String stallDocId,
    required String orderId,
  }) async {
    // Get the order
    final orderRef = FirebaseFirestore.instance
        .collection('Hawker')
        .doc(stallDocId)
        .collection('profile')
        .doc('Profile')
        .collection('order')
        .doc(orderId);

    final orderSnapshot = await orderRef.get();

    if (!orderSnapshot.exists) {
      throw Exception('Order does not exist');
    }

    final orderData = orderSnapshot.data()!;

    // Get customer ID
    final customerId = orderData['customerId']?.toString();

    if (customerId == null || customerId.isEmpty) {
      throw Exception('Customer ID not found in order');
    }

    // Get the comment from the order
    final comment = (orderData['comment'] ?? '').toString().trim();

    // Mark order as completed
    await orderRef.update({'status': 'served'});

    // If the customer left no comment, don't create an empty review
    if (comment.isEmpty) {
      return;
    }

    // Copy comment into the stall's reviews
    final reviewRef = FirebaseFirestore.instance
        .collection('Hawker')
        .doc(stallDocId)
        .collection('reviews')
        .doc(customerId);

    await reviewRef.set({
      'comment': comment,
      'updatedAt': Timestamp.now(),
    }, SetOptions(merge: true));
  }

  Future<Map<String, String>> _loadStallProfileInfo(
    String hawkerStallDocId,
  ) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('Hawker')
        .doc(hawkerStallDocId)
        .collection('profile')
        .doc('Profile')
        .get();

    final data = snapshot.data() ?? <String, dynamic>{};

    final stallNumber = (data['stallnum'] ?? data['stallNum'] ?? '')
        .toString()
        .trim();

    final stallName = (data['stallname'] ?? data['stallName'] ?? '')
        .toString()
        .trim();

    return {'stallNumber': stallNumber, 'stallName': stallName};
  }


  static const String stallDocId = 'test_hawker_001';

  CollectionReference<Map<String, dynamic>> _ordersRefForStall(
    String hawkerStallDocId,
  ) {
    return FirebaseFirestore.instance
        .collection('Hawker')
        .doc(hawkerStallDocId)
        .collection('profile')
        .doc('Profile')
        .collection('order');
  }



  Future<void> _deleteCollection(
    CollectionReference<Map<String, dynamic>> ref,
  ) async {
    final snapshot = await ref.get();

    if (snapshot.docs.isEmpty) {
      return;
    }

    final batch = FirebaseFirestore.instance.batch();

    for (final doc in snapshot.docs) {
      batch.delete(doc.reference);
    }

    await batch.commit();
  }


  Future<void> clearOrderHistoryEverywhere() async {
    final customerId = CustomerService.instance.current?.id;

    try {
      if (customerId != null) {
        final ordersSnapshot = await FirebaseFirestore.instance
            .collectionGroup('order')
            .where('customerId', isEqualTo: customerId)
            .get();

        if (ordersSnapshot.docs.isNotEmpty) {
          final batch = FirebaseFirestore.instance.batch();

          for (final doc in ordersSnapshot.docs) {
            batch.delete(doc.reference);
          }

          await batch.commit();
        }

        await _deleteCollection(
          FirebaseFirestore.instance
              .collection('customers')
              .doc(customerId)
              .collection('orderHistory'),
        );
      } else {
        await _deleteCollection(_ordersRefForStall(stallDocId));
      }

      orders.clear();

      _recentOrder = null;

      notifyListeners();
    } catch (e) {
      debugPrint('Error clearing order history: $e');
    }
  }


  CollectionReference<Map<String, dynamic>> reviewsRef(String stallDocId) {
    return FirebaseFirestore.instance
        .collection('Hawker')
        .doc(stallDocId)
        .collection('reviews');
  }



  Future<CartOrder> placeOrder({required bool dinein}) async {
    if (_items.isEmpty) {
      throw Exception('Cannot place an order with an empty cart.');
    }

  
    final Map<String, List<CartItem>> groupedItems = {};

    for (final item in _items) {
      final key = item.stallDocId.trim().isNotEmpty
          ? item.stallDocId.trim()
          : stallDocId;

      groupedItems.putIfAbsent(key, () => <CartItem>[]).add(item);
    }

    final double checkoutGrandTotal = totalDue(dineIn: dinein);

    final int earnedPoints = (checkoutGrandTotal * pointsPerDollar).round();

    final customer = CustomerService.instance.current;

    final List<CartOrder> createdOrders = [];

    double remainingTakeoutFee = dinein ? 0.0 : takeoutFee;

    for (final entry in groupedItems.entries) {
      final targetStallDocId = entry.key;

      final stallItems = entry.value;

      final ordersRef = _ordersRefForStall(targetStallDocId);

      final docRef = ordersRef.doc();

      final countSnapshot = await ordersRef.count().get();

      final int nextOrderNum = (countSnapshot.count ?? 0) + 1;

      final stallProfile = await _loadStallProfileInfo(targetStallDocId);

      final String stallNumber = stallProfile['stallNumber'] ?? '';

      final String stallName =
          (stallProfile['stallName'] ?? '').trim().isNotEmpty
          ? stallProfile['stallName']!
          : stallItems.first.stall;

      final orderLines = stallItems.map((item) {
        return item.quantity > 1 ? '${item.name} x${item.quantity}' : item.name;
      }).toList();

      final int stallQuantity = stallItems.fold(
        0,
        (sum, item) => sum + item.quantity,
      );

      final double stallSubtotal = stallItems.fold(
        0.0,
        (sum, item) => sum + item.total,
      );

      final double stallFee = remainingTakeoutFee > 0
          ? remainingTakeoutFee
          : 0.0;

      remainingTakeoutFee = 0.0;

      final double stallOrderTotal = stallSubtotal + stallFee;

    
      final hawkerOrderPayload = {
        'ordersL': orderLines,
        'time': Timestamp.now(),
        'totalp': stallOrderTotal,
        'dinein': dinein,
        'ordernum': nextOrderNum,
        'quantity': stallQuantity,
        'stallName': stallName,
        'stallnum': stallNumber,
        'status': 'preparing',

        if (customer != null) 'customerId': customer.id,
      };

     
      final customerOrderPayload = {
        'Orders': orderLines,
        'Time': Timestamp.now(),
        'Total': stallOrderTotal.toStringAsFixed(2),
        'dinein': dinein,
        'ordernum': nextOrderNum,
        'quantity': stallQuantity,
        'stallName': stallName,
        'stallnum': stallNumber,
        'status': 'preparing',
        'comment': '',

        if (customer != null) 'customerId': customer.id,
      };

      await docRef.set(hawkerOrderPayload, SetOptions(merge: true));

      if (customer != null) {
        await FirebaseFirestore.instance
            .collection('customers')
            .doc(customer.id)
            .collection('orderHistory')
            .doc(docRef.id)
            .set(customerOrderPayload, SetOptions(merge: true));
      }

      final String title =
          '$stallQuantity item${stallQuantity > 1 ? 's' : ''} · ${stallItems.first.name}';

      final String subtitle =
          '$stallQuantity dish${stallQuantity > 1 ? 'es' : ''} • \$${stallOrderTotal.toStringAsFixed(2)}';

      createdOrders.add(
        CartOrder(
          orderId: docRef.id,
          title: title,
          subtitle: subtitle,
          amount: '\$${stallOrderTotal.toStringAsFixed(2)}',
          date: DateTime.now(),
          dinein: dinein,
          dishNames: stallItems.map((item) => item.name).toList(),
          stallName: stallName,
          stallDocId: targetStallDocId,
          stallNumber: stallNumber,
          orderNumber: nextOrderNum,
          quantity: stallQuantity,
          pointsEarned: earnedPoints,
        ),
      );
    }

    if (customer != null) {
      await CustomerService.instance.addPoints(earnedPoints);
    } else {
      _totalPoints += earnedPoints;
    }

    createdOrders.sort((a, b) => b.date.compareTo(a.date));

    if (createdOrders.isNotEmpty) {
      _recentOrder = createdOrders.first;

      orders.insertAll(0, createdOrders);
    }

    clearCart();

    return _recentOrder!;
  }



  Future<void> redeemPoints() async {
    if (!canRedeemPoints) {
      return;
    }

    final double requiredPoints = totalAmount / 0.02;

    final int pointsToUse = min(availablePoints, requiredPoints.ceil());

    if (pointsToUse <= 0) {
      return;
    }

    redeemedPoints = pointsToUse;

    discountAmount = _discountFromPoints(pointsToUse);

    if (CustomerService.instance.isLoggedIn) {
      await CustomerService.instance.deductPoints(pointsToUse);
    } else {
      _totalPoints -= pointsToUse;

      if (_totalPoints < 0) {
        _totalPoints = 0;
      }
    }

    notifyListeners();
  }


  Future<void> loadOrderHistoryFromFirestore() async {
    try {
      final customer = CustomerService.instance.current;

      if (customer == null) {
        return;
      }

      final snapshot = await FirebaseFirestore.instance
          .collection('customers')
          .doc(customer.id)
          .collection('orderHistory')
          .get();

      final Map<String, Map<String, String>> profileCache = {};

      final List<CartOrder> loadedOrders = [];

      for (final doc in snapshot.docs) {
        final data = doc.data();

        final pathParts = doc.reference.path.split('/');

        String orderStallDocId = stallDocId;

        if (pathParts.length >= 2 && pathParts[0] == 'Hawker') {
          orderStallDocId = pathParts[1];
        }

        if (!profileCache.containsKey(orderStallDocId)) {
          profileCache[orderStallDocId] = await _loadStallProfileInfo(
            orderStallDocId,
          );
        }

        final fallbackProfile = profileCache[orderStallDocId] ?? {};

        final fallbackStallNumber = fallbackProfile['stallNumber'] ?? '';

        final fallbackStallName = fallbackProfile['stallName'] ?? '';

        final dishNames = List<String>.from(
          data['dishNames'] as List? ??
              data['ordersL'] as List? ??
              data['ordersH'] as List? ??
              data['Orders'] as List? ??
              const [],
        );

        final totalValue =
            (data['totalp'] as num?)?.toDouble() ??
            double.tryParse((data['totalp'] ?? '').toString()) ??
            (data['totalH'] as num?)?.toDouble() ??
            double.tryParse((data['Total'] ?? '').toString()) ??
            0;

        final amount = (data['amount'] as String?)?.isNotEmpty == true
            ? data['amount'] as String
            : '\$${totalValue.toStringAsFixed(2)}';

        final DateTime placedAt =
            (data['placedAt'] as Timestamp?)?.toDate() ??
            (data['createdAt'] as Timestamp?)?.toDate() ??
            (data['time'] as Timestamp?)?.toDate() ??
            (data['timeH'] as Timestamp?)?.toDate() ??
            (data['Time'] as Timestamp?)?.toDate() ??
            DateTime.now();

        final title = (data['title'] as String?)?.isNotEmpty == true
            ? data['title'] as String
            : '${dishNames.length} item${dishNames.length == 1 ? '' : 's'}';

        final subtitle = (data['subtitle'] as String?)?.isNotEmpty == true
            ? data['subtitle'] as String
            : '${dishNames.length} dish${dishNames.length == 1 ? '' : 'es'} • $amount';

        final stallNumFromOrder = (data['stallnum'] ?? data['stallNum'] ?? '')
            .toString()
            .trim();

        final stallNameFromOrder =
            (data['stallName'] ?? data['stallname'] ?? '').toString().trim();

        loadedOrders.add(
          CartOrder(
            orderId: doc.id,
            title: title,
            subtitle: subtitle,
            amount: amount,
            date: placedAt,
            dinein:
                (data['dinein'] as bool?) ?? (data['dineinH'] as bool?) ?? true,
            dishNames: dishNames,
            stallName: stallNameFromOrder.isNotEmpty
                ? stallNameFromOrder
                : fallbackStallName,
            stallDocId: orderStallDocId,
            stallNumber: stallNumFromOrder.isNotEmpty
                ? stallNumFromOrder
                : fallbackStallNumber,
            orderNumber: (data['ordernum'] as num?)?.toInt() ?? 0,
            quantity: (data['quantity'] as num?)?.toInt() ?? dishNames.length,
            status: _normalizeOrderStatus(data),
            dishRatings: Map<String, int>.from(
              data['orderInfo'] as Map<String, dynamic>? ??
                  data['ratings'] as Map<String, dynamic>? ??
                  {},
            ),
            comment:
                (data['comment'] as String?) ??
                (data['review'] as String?) ??
                '',
          ),
        );
      }

      orders
        ..clear()
        ..addAll(loadedOrders)
        ..sort((a, b) => b.date.compareTo(a.date));

      notifyListeners();
    } catch (e) {
  
      debugPrint('Could not load order history: $e');
    }
  }



  Stream<DocumentSnapshot<Map<String, dynamic>>> watchOrder(
    String orderId, {
    String? stallDocId,
  }) {
    final stall = stallDocId ?? CartService.stallDocId;

    return _ordersRefForStall(stall).doc(orderId).snapshots();
  }


  Stream<QuerySnapshot<Map<String, dynamic>>> watchOrderHistory() {
    final customer = CustomerService.instance.current;

    if (customer == null) {
      return const Stream<QuerySnapshot<Map<String, dynamic>>>.empty();
    }

    return FirebaseFirestore.instance
        .collection('customers')
        .doc(customer.id)
        .collection('orderHistory')
        .snapshots();
  }

  Future<void> saveOrderRating({
    required CartOrder order,
    required Map<String, int> dishRatings,
    required String comment,
  }) async {
    order.dishRatings = dishRatings;

    order.comment = comment;

    await _ordersRefForStall(order.stallDocId).doc(order.orderId).set({
      'orderInfo': dishRatings,
      'comment': comment,
    }, SetOptions(merge: true));
  }


  Future<double> saveStallReview({
    required String stallDocId,
    required String customerId,
    required int stars,
    required String comment,
  }) async {
    await reviewsRef(stallDocId).doc(customerId).set({
      'stars': stars,
      'comment': comment,
      'updatedAt': Timestamp.now(),
    }, SetOptions(merge: true));

    final snapshot = await reviewsRef(stallDocId).get();

    if (snapshot.docs.isEmpty) {
      return stars.toDouble();
    }

    double sum = 0;

    int count = 0;

    for (final doc in snapshot.docs) {
      final data = doc.data();

      final s = (data['stars'] as num?)?.toDouble();

      if (s != null) {
        sum += s;
        count++;
      }
    }

    final avg = count == 0 ? stars.toDouble() : sum / count;

    return avg;
  }

  Future<Map<String, dynamic>?> loadStallReview({
    required String stallDocId,
    required String customerId,
  }) async {
    final snapshot = await reviewsRef(stallDocId).doc(customerId).get();

    return snapshot.data();
  }
}
