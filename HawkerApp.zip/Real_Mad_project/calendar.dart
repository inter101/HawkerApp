import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';



class calendarbar extends StatefulWidget {
  final DateTime selectedDate;
  final Function(DateTime) onDateChanged;
  const calendarbar({
    super.key,
    required this.selectedDate,
    required this.onDateChanged,
  });

  @override
  State<calendarbar> createState() => _calendarbarState();
}

class _calendarbarState extends State<calendarbar> {
  void fun() async {
    final calendarthingy = await showDatePicker(
      context: context,
      initialDate: widget.selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),

      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: kOrange, // selected day
              onPrimary: Colors.white, // selected day text
              surface: Colors.white, // dialog background
              onSurface: Colors.black,
            ),

            dialogTheme: DialogThemeData(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
                side: const BorderSide(color: kOrange, width: 2),
              ),
            ),

            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: kOrange,
              ),
            ),
          ),

          child: child!,
        );
      },
    );
    if (calendarthingy != null) {
      widget.onDateChanged(calendarthingy);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      width: double.infinity,

      decoration: BoxDecoration(
        color: kOrange,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconButton(
            onPressed: () async {
              widget.onDateChanged(
                widget.selectedDate.subtract(const Duration(days: 1)),
              );
            },
            icon: Icon(Icons.chevron_left, size: 40),
          ),
          IconButton(
            onPressed: fun,
            icon: Icon(Icons.calendar_month, size: 35),
          ),
          Text(
            "${widget.selectedDate.day}/${widget.selectedDate.month}/${widget.selectedDate.year}",
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
          ),
          SizedBox(width: 35),
          IconButton(
            onPressed: () async {
              widget.onDateChanged(
                widget.selectedDate.add(const Duration(days: 1)),
              );
            },
            icon: Icon(Icons.chevron_right, size: 40),
          ),
        ],
      ),
    );
  }
}
