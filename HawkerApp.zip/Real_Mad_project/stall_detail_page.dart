import 'package:flutter/material.dart';

import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';
import 'package:flutter_application_1/Real_Mad_project/firebase_image.dart';
import 'package:flutter_application_1/Real_Mad_project/local_identity.dart';

import 'package:flutter_application_1/Real_Mad_project/points_badge.dart';

class StallDetailPage extends StatefulWidget {
  const StallDetailPage({super.key, required this.stall});

  final Map<String, dynamic> stall;

  @override
  State<StallDetailPage> createState() => _StallDetailPageState();
}

class _StallDetailPageState extends State<StallDetailPage> {
  final TextEditingController _reviewController = TextEditingController();
  int _selectedRating = 0;
  bool _hasSubmitted = false;
  bool _isSaving = false;
  bool _isLoadingExistingReview = true;

  // TODO(Kaviya): If stall doc IDs use a different key, update these lookups.
  String get _stallDocId =>
      (widget.stall['docId'] ?? widget.stall['id'] ?? CartService.stallDocId)
          as String;

  @override
  void initState() {
    super.initState();
    _loadExistingReview();
  }

  Future<void> _loadExistingReview() async {
    final customerId =
        CustomerService.instance.current?.id ??
        await LocalIdentity.customerId();
    final existing = await CartService.instance.loadStallReview(
      stallDocId: _stallDocId,
      customerId: customerId,
    );

    if (!mounted) return;
    if (existing != null) {
      setState(() {
        _selectedRating = (existing['stars'] as num?)?.toInt() ?? 0;
        _reviewController.text = existing['comment'] as String? ?? '';
        _hasSubmitted = _selectedRating > 0;
      });
    }
    setState(() => _isLoadingExistingReview = false);
  }

  @override
  void dispose() {
    _reviewController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final stall = widget.stall;
    final name = stall['name'] as String;
    final category = stall['category'] as String;
    final unitNo = stall['unitNo'] as String;
    final stars = stall['stars'] as int;
    final imageUrl = stall['imageUrl'] as String;
    final menu = (stall['menu'] as List).cast<Map<String, dynamic>>();

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(35),
                    bottomRight: Radius.circular(35),
                  ),
                  child: Container(
                    height: 220,
                    decoration: const BoxDecoration(
                      color: Color.fromRGBO(243, 129, 27, 0.9),
                    ),
                    padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white,
                          ),
                          child: IconButton(
                            icon: const Icon(
                              Icons.arrow_back,
                              color: Colors.black87,
                            ),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ),
                        const SizedBox(width: 15),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: FirebaseImage(
                            imageUrl,
                            width: 80,
                            height: 80,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Category: $category  •  $unitNo',
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Colors.white70,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: List.generate(5, (index) {
                                  return Icon(
                                    index < stars
                                        ? Icons.star
                                        : Icons.star_border,
                                    size: 18,
                                    color: Colors.white,
                                  );
                                }),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 50,
                  right: 20,
                  child: PointsBadge(onDark: true),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(
                        Icons.restaurant_menu,
                        color: Color.fromRGBO(243, 129, 27, 1),
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Menu',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  if (menu.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: Colors.grey.shade100,
                      ),
                      child: const Text(
                        'This stall has not uploaded a menu yet.',
                        style: TextStyle(color: Colors.black54),
                      ),
                    )
                  else
                    for (final dish in menu) _buildMenuItem(dish),
                  const SizedBox(height: 25),
                  const Text(
                    'Rate this stall',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.black12),
                    ),
                    child: _isLoadingExistingReview
                        ? const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Center(
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: List.generate(5, (index) {
                                  final filled = index < _selectedRating;
                                  return IconButton(
                                    iconSize: 34,
                                    icon: Icon(
                                      filled ? Icons.star : Icons.star_border,
                                      color: filled
                                          ? Colors.amber
                                          : Colors.grey.shade400,
                                    ),
                                    onPressed: () => setState(
                                      () => _selectedRating = index + 1,
                                    ),
                                  );
                                }),
                              ),
                              if (_hasSubmitted) ...[
                                const SizedBox(height: 4),
                                Center(
                                  child: Text(
                                    'You rated this stall — feel free to update it below.',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.green.shade700,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 8),
                              TextField(
                                controller: _reviewController,
                                maxLines: 3,
                                decoration: InputDecoration(
                                  hintText: 'Share your experience ....',
                                  filled: true,
                                  fillColor: Colors.grey.shade100,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(14),
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color.fromRGBO(
                                      243,
                                      129,
                                      27,
                                      1,
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 14,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                  ),
                                  onPressed: _isSaving ? null : _submitReview,
                                  child: _isSaving
                                      ? const SizedBox(
                                          height: 18,
                                          width: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            color: Colors.white,
                                          ),
                                        )
                                      : Text(
                                          _hasSubmitted
                                              ? 'Update Review'
                                              : 'Submit Review',
                                          style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                ),
                              ),
                            ],
                          ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(Map<String, dynamic> dish) {
    final dishName = dish['name'] as String;
    final price = dish['price'] as double;
    final dishStars = dish['stars'] as double;
    final available = dish['available'] as bool? ?? true;
    final isOpen = (widget.stall['status'] as bool?) ?? true;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: FirebaseImage(
              dish['imageUrl'] as String,
              width: 60,
              height: 60,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  dishName,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Icon(Icons.star, size: 14, color: Colors.amber.shade600),
                    const SizedBox(width: 3),
                    Text(
                      dishStars.toStringAsFixed(1),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '\$${price.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(243, 129, 27, 1),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: available ? Colors.green.shade100 : Colors.red.shade100,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              available ? 'Available' : 'Sold Out',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: available ? Colors.green.shade700 : Colors.red.shade700,
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: Icon(
              Icons.add_circle,
              size: 28,
              color: (available && isOpen)
                  ? const Color.fromRGBO(243, 129, 27, 1)
                  : Colors.grey.shade300,
            ),
            onPressed: (available && isOpen)
                ? () => _addDishToCart(dish)
                : null,
          ),
        ],
      ),
    );
  }

  void _addDishToCart(Map<String, dynamic> dish) {
    final stallName = widget.stall['name'] as String;
    final dishName = dish['name'] as String;
    final price = dish['price'] as double;
    final available = dish['available'] as bool? ?? true;
    try {
      CartService.instance.addItem(
        CartItem(
          id: '$stallName-$dishName',
          name: dishName,
          stall: stallName,
          stallDocId: _stallDocId,
          price: price,
          imageUrl: dish['imageUrl'] as String?,
          available: available,
        ),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Added $dishName to cart'),
          duration: const Duration(seconds: 1),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Future<void> _submitReview() async {
    if (_selectedRating == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a star rating first')),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      final customerId =
          CustomerService.instance.current?.id ??
          await LocalIdentity.customerId();
      final newAvg = await CartService.instance.saveStallReview(
        stallDocId: _stallDocId,
        customerId: customerId,
        stars: _selectedRating,
        comment: _reviewController.text.trim(),
      );

      if (!mounted) return;
      // Update the local stall map so the calling page reflects the
      // new average rating (rounded to an int for existing UI).
      setState(() {
        widget.stall['stars'] = newAvg.round();
        _hasSubmitted = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _hasSubmitted ? 'Review updated!' : 'Thanks for your review!',
          ),
        ),
      );
      // Note: unlike before, we deliberately do NOT reset _selectedRating
      // or clear _reviewController here — the whole point is that the
      // customer's rating stays visible and can be edited/resubmitted.
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not save review: $e')));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }
}
