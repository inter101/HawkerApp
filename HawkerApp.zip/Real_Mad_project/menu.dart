import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/addmenu.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/menupage.dart';
import 'package:flutter_application_1/Real_Mad_project/qaz.dart';

class menu extends StatefulWidget {
  const menu({super.key});

  @override
  State<menu> createState() => _menuState();
}

class _menuState extends State<menu> {
  bool plax = true;
  @override
  Widget build(BuildContext context) {
    var number = databaseservice.getCountmenu();
    var you = databaseservice.getOutOfStockCount();
    void test() {
      setState(() {});
    }

    return Scaffold(
      extendBody: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: kOrange,
        toolbarHeight: 130,
        surfaceTintColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        title: Row(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  'Item',
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                ),

                SizedBox(height: 4),
                Row(
                  children: [
                    SizedBox(width: 8),
                    Text(
                      'Menu',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    SizedBox(width: 8),
                    Text(
                      '${number} Items',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 8),
                    Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFFEF7DE),
                        border: Border.all(color: Color(0xFFFFE8D4)),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Padding(
                        padding: EdgeInsetsGeometry.all(5),
                        child: Container(
                          child: Text(
                            '${you} out of stock',
                            style: TextStyle(
                              color: kOrange,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      {
                        plax = !plax;
                      }
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFFFFFFF),
                    side: BorderSide(color: Colors.grey, width: 2),
                  ),

                  child: Padding(
                    padding: EdgeInsets.fromLTRB(2.5, 10, 2.5, 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(width: 2.5),
                        Icon(Icons.add, color: Colors.black),
                        SizedBox(width: 2.5),
                        Text(
                          'Add dish',
                          style: TextStyle(color: Colors.black, fontSize: 16),
                        ),
                        SizedBox(width: 2.5),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(width: 10),
          ],
        ),
      ),
      body: Container(
        color: Colors.white,
        padding: EdgeInsets.symmetric(horizontal: 25),
        child: (plax)
            ? menupage(
                onStockChanged: () {
                  setState(
                    () {},
                  ); // recomputes `you` and `number` in menu's build()
                },
              )
            : additem(
                onCancel: () {
                  setState(() {
                    plax = true;
                  });
                },
              ),
      ),
      bottomNavigationBar: qaz(),
    );
  }
}
