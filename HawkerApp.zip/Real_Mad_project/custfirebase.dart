import 'package:cloud_firestore/cloud_firestore.dart';

class Custfirebase {
  static CollectionReference customers = FirebaseFirestore.instance.collection('customers');

  // Generates customer numbering e.g. cust_001, cust_002
  static Future<String> _generateNextCustomerId() async {
    QuerySnapshot snapshot = await customers.get();
    int nextNumber = snapshot.docs.length + 1;
    return 'cust_${nextNumber.toString().padLeft(3, '0')}';
  }

  // Set up customer profile fields
  static Future<void> signUpCustomer(String email, String password) async {
    String customerId = await _generateNextCustomerId();

    await customers.doc(customerId).set({
      'email': email,
      'password': password,
      'Points': 0,
      'rating': 0,
      'name': 'HawkerGo User',
      'loggedIn': false,
      'paymentCards': <Map<String, dynamic>>[],
    });

    // Empty orderHistory subcollection
  }

  static Future<bool> loginCustomer(String email, String password) async {
    QuerySnapshot qs = await customers
        .where('email', isEqualTo: email)
        .where('password', isEqualTo: password)
        .limit(1)
        .get();
    return qs.docs.isNotEmpty;
  }

  static Future<bool> checkCustomerEmailExists(String email) async {
    QuerySnapshot qs = await customers.where('email', isEqualTo: email).limit(1).get();
    return qs.docs.isNotEmpty;
  }

  static Future<void> updateCustomerPassword(String email, String newPassword) async {
    QuerySnapshot qs = await customers.where('email', isEqualTo: email).limit(1).get();
    if (qs.docs.isNotEmpty) {
      await qs.docs.first.reference.update({'password': newPassword});
    }
  }
}