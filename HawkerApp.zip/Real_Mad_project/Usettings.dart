class Usettings {
  String stallname;
  String stallnum;
  bool status;
  String pic;
  Usettings(this.stallname, this.stallnum, this.status, this.pic);
}
