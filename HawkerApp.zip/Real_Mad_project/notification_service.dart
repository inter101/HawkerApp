import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Handles local (on-device) notifications, e.g. telling the user
/// their order is ready.
class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _permissionsGranted = false;

  /// Call this once, in main() after Firebase is initialized.
  Future<void> init() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    // Your installed version of flutter_local_notifications requires
    // `settings` as a NAMED parameter (this changed in a recent release).
    await _plugin.initialize(settings: settings);

    _permissionsGranted = await _requestPermissions();
  }

  Future<bool> _requestPermissions() async {
    try {
      final androidImplementation = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      if (androidImplementation != null) {
        final granted = await androidImplementation.requestNotificationsPermission();
        return granted ?? false;
      }

      final iosImplementation =
          _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      if (iosImplementation != null) {
        final granted = await iosImplementation.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
        return granted ?? false;
      }
    } catch (_) {
      return false;
    }

    // If the platform does not require runtime permission, assume it's okay.
    return true;
  }

  Future<bool> _ensurePermissions() async {
    if (_permissionsGranted) return true;
    _permissionsGranted = await _requestPermissions();
    return _permissionsGranted;
  }

  /// Shows "Your order is ready" — wording depends on dine-in vs takeaway.
  Future<void> showOrderReadyNotification({required bool dinein, String? message}) async {
    if (!await _ensurePermissions()) {
      return;
    }
    const androidDetails = AndroidNotificationDetails(
      'order_updates',
      'Order Updates',
      channelDescription: 'Notifies you when your order is ready',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(),
    );

    final String title = dinein ? 'Your meal is ready! 🍽️' : 'Your order is ready! 🥡';
    final String body = message ?? (dinein
        ? 'Your meal is ready to be eaten — enjoy!'
        : 'Your order is ready for pickup.');

    // Same here — id, title, body, notificationDetails are all NAMED
    // in your installed version.
    await _plugin.show(
      id: DateTime.now().millisecondsSinceEpoch ~/ 100000,
      title: title,
      body: body,
      notificationDetails: details,
    );
  }

  /// Shows an OTP notification for payment verification.
  Future<void> showOtpNotification({required String otp}) async {
    if (!await _ensurePermissions()) {
      return;
    }

    const androidDetails = AndroidNotificationDetails(
      'payment_otp',
      'Payment OTP',
      channelDescription: 'One-time password for payment verification',
      importance: Importance.high,
      priority: Priority.high,
    );
    const details = NotificationDetails(
      android: androidDetails,
      iOS: DarwinNotificationDetails(),
    );

    await _plugin.show(
      id: 1001,
      title: 'Verify your payment card',
      body: 'Enter OTP: $otp',
      notificationDetails: details,
    );
  }
}
