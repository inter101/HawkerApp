import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/emptyorder.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/orderwidget.dart';
import 'package:flutter_application_1/Real_Mad_project/qaz.dart';


class order extends StatefulWidget {
  const order({super.key});

  @override
  State<order> createState() => _orderState();
}

class _orderState extends State<order> {
  bool loading = true;
  void initState() {
    super.initState();
    loadOrders();
  }

  Future<void> loadOrders() async {
    await databaseservice.getallorders();

    setState(() {
      loading = false;
    });
  }


  @override
  Widget build(BuildContext context) {
    final int p = databaseservice.getorderCount();

    return Scaffold(
      extendBody: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: kOrange,
        toolbarHeight: 130,
        surfaceTintColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        title: Row(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                
                Text(
                  'Live',
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                ),

                SizedBox(height: 4),
                Row(
                  children: [
                    SizedBox(width: 8),
                    Text(
                      'Orders',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      body: Container(
        padding: EdgeInsets.fromLTRB(25, 0, 25, 0),
        color: Colors.white,
        height: 1000,
        child: (p == 0)
            ? empty()
            : orderwidget(
                onOrdersChanged: () {
                  setState(() {});
                },
              ),
      ),
      bottomNavigationBar: qaz(),
    );
  }
}
