class MenuItem {
  String name;
  double price;
  String category;
  String image;
  bool stock;

  MenuItem(
    this.name,
    this.price,
    this.category,
    this.image,
    this.stock
  );
}