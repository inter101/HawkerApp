import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/app_bottom_nav.dart';
import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/points_badge.dart';

class RateOrderPage extends StatefulWidget {
  const RateOrderPage({super.key});

  @override
  State<RateOrderPage> createState() => _RateOrderPageState();
}

class _RateOrderPageState extends State<RateOrderPage> {
  final CartService cartService = CartService.instance;
  final TextEditingController _commentController = TextEditingController();

  // Star rating per dish.
  late Map<String, int> _dishRatings;

  // Tracks whether this order already has a submitted rating.
  bool _hasSubmitted = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    final order = cartService.recentOrder;

    // Pre-fill any previously saved rating for this order.
    _dishRatings = {
      for (final dish in order?.dishNames ?? <String>[])
        dish: order?.dishRatings[dish] ?? 0,
    };
    _commentController.text = order?.comment ?? '';
    _hasSubmitted = order?.hasRated ?? false;
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final order = cartService.recentOrder;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Your Dishes',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (order == null)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Text(
                          'No recent order to rate.',
                          style: TextStyle(color: Colors.grey),
                        ),
                      )
                    else
                      for (final dish in order.dishNames)
                        _buildDishRatingCard(order.stallName, dish),
                    const SizedBox(height: 20),
                    _buildCommentBox(),
                    if (_hasSubmitted) ...[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.green.shade200),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.check_circle,
                              color: Colors.green.shade700,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Rating saved — you can still update it below.',
                                style: TextStyle(
                                  color: Colors.green.shade800,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 55,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color.fromRGBO(
                            243,
                            129,
                            27,
                            1,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          elevation: 5,
                        ),
                        onPressed: (order == null || _isSaving)
                            ? null
                            : _submitRatings,
                        icon: _isSaving
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.check, color: Colors.white),
                        label: Text(
                          _hasSubmitted ? 'Update Rating' : 'Submit Rating',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Center(
                      child: TextButton(
                        onPressed: _goToHistory,
                        child: Text(
                          _hasSubmitted ? 'Done' : 'Maybe Later',
                          style: const TextStyle(
                            color: Colors.grey,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: buildAppBottomNav(context, 2),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 25),
      decoration: const BoxDecoration(
        color: Color.fromRGBO(243, 129, 27, 0.9),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(35),
          bottomRight: Radius.circular(35),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Align(
            alignment: Alignment.centerRight,
            child: PointsBadge(onDark: true),
          ),
          const SizedBox(height: 10),
          const Text(
            'Rate Your Order',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'How was your meal? Tap a star to rate each dish.',
            style: TextStyle(fontSize: 13, color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _buildDishRatingCard(String stallName, String dishName) {
    final rating = _dishRatings[dishName] ?? 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.orange.shade100,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.fastfood, color: Colors.black87),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  stallName,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color.fromRGBO(243, 129, 27, 1),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  dishName,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: List.generate(5, (index) {
                    final filled = index < rating;
                    return GestureDetector(
                      onTap: () =>
                          setState(() => _dishRatings[dishName] = index + 1),
                      child: Icon(
                        filled ? Icons.star : Icons.star_border,
                        size: 24,
                        color: filled ? Colors.amber : Colors.grey.shade400,
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCommentBox() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(
                Icons.chat_bubble_outline,
                color: Color.fromRGBO(243, 129, 27, 1),
              ),
              SizedBox(width: 8),
              Text(
                'Leave a comment',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _commentController,
            maxLines: 4,
            decoration: InputDecoration(
              hintText: 'Tell us about your experience...',
              filled: true,
              fillColor: Colors.grey.shade100,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _submitRatings() async {
    final order = cartService.recentOrder;
    if (order == null) return;

    final bool wasSubmitted = _hasSubmitted;
    setState(() => _isSaving = true);
    try {
      await cartService.saveOrderRating(
        order: order,
        dishRatings: _dishRatings,
        comment: _commentController.text.trim(),
      );
      if (!mounted) return;
      setState(() => _hasSubmitted = true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            wasSubmitted ? 'Rating updated!' : 'Thanks for rating your order!',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Could not save rating: $e')));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _goToHistory() {
    Navigator.pushReplacementNamed(context, '/cushistory');
  }
}
