import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/app_bottom_nav.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';


class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  void initState() {
    super.initState();
    _loadCustomer();
    CustomerService.instance.addListener(_onCustomerChanged);
  }

  Future<void> _loadCustomer() async {
    await CustomerService.instance.refresh();
    if (!mounted) return;
    setState(() {});
  }

  void _onCustomerChanged() {
    if (!mounted) return;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final customer = CustomerService.instance.current;
    final name = customer?.name ?? 'Guest User';

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 110),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 40, 20, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Center(
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 55,
                        backgroundColor: const Color.fromRGBO(255, 238, 215, 1),
                        foregroundImage: customer?.photoUrl != null ? NetworkImage(customer!.photoUrl!) : null,
                        child: customer?.photoUrl == null
                            ? const Icon(Icons.person_outline, size: 60, color: Colors.black87)
                            : null,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        name,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        customer != null ? 'Logged in' : 'New to HawkerGo',
                        style: const TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                const SizedBox(height: 10),
                const Text(
                  'Manage your account, orders and support.',
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
                const SizedBox(height: 30),
                _buildProfileTile(context, Icons.person, 'Account Settings', 'Name, email, notifications', () {
                  Navigator.pushNamed(context, '/account_settings');
                }),
                _buildProfileTile(context, Icons.help_outline, 'Help & Support', 'Need assistance?', () {
                  Navigator.pushNamed(context, '/help_support');
                }),
                _buildProfileTile(
                  context,
                  Icons.logout,
                  'Sign Out',
                  customer != null ? 'Log out of your account' : 'Remove saved data',
                  () async {
                    await CustomerService.instance.logout();
                    if (!context.mounted) return;
                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      '/mainhome',
                      (route) => false,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: buildAppBottomNav(context, 4),
    );
  }

  Widget _buildProfileTile(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.black12),
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.orange.shade100,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon, color: Colors.black87),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(fontSize: 13, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.black45),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    CustomerService.instance.removeListener(_onCustomerChanged);
    super.dispose();
  }
}