import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/maindish.dart';


//page with all the listviews
class menupage extends StatefulWidget {
  final VoidCallback onStockChanged;
  const menupage({super.key, required this.onStockChanged});

  @override
  State<menupage> createState() => _menupageState();
}

class _menupageState extends State<menupage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 0, 30),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 30),
            Container(
              child: Text(
                'Mains',
                style: TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            const Divider(height: 1, thickness: 2, color: Color(0xFFE0E0E0)),

            SizedBox(
              child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: databaseservice.getCategoryCount('Mains'),
                itemBuilder: (context, index) {
                  return menuwidget(
                    category: 'Mains',
                    index: index,
                    onDelete: () {
                      setState(() {});
                    },
                    onStockChanged: widget.onStockChanged,
                  );
                },
              ),
            ),
            SizedBox(height: 5),
            Container(
              child: Text(
                'Add-ons',
                style: TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            const Divider(height: 1, thickness: 2, color: Color(0xFFE0E0E0)),

            SizedBox(
              child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: databaseservice.getCategoryCount('Add-ons'),
                itemBuilder: (context, index) {
                  return menuwidget(
                    category: 'Add-ons',
                    index: index,
                    onDelete: () {
                      setState(() {});
                    },
                    onStockChanged: widget.onStockChanged,
                  );
                },
              ),
            ),
            SizedBox(height: 5),
            Container(
              child: Text(
                'Sides',
                style: TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            const Divider(height: 1, thickness: 2, color: Color(0xFFE0E0E0)),

            SizedBox(
              child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: databaseservice.getCategoryCount('Sides'),
                itemBuilder: (context, index) {
                  return menuwidget(
                    category: 'Sides',
                    index: index,
                    onDelete: () {
                      setState(() {});
                    },
                    onStockChanged: widget.onStockChanged,
                  );
                },
              ),
            ),
            Container(
              child: Text(
                'Drinks',
                style: TextStyle(
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            const Divider(height: 1, thickness: 2, color: Color(0xFFE0E0E0)),

            SizedBox(
              child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: databaseservice.getCategoryCount('Drinks'),
                itemBuilder: (context, index) {
                  return menuwidget(
                    category: 'Drinks',
                    index: index,
                    onDelete: () {
                      setState(() {});
                    },
                    onStockChanged: widget.onStockChanged,
                  );
                },
              ),
            ),
            SizedBox(height: 50),
          ],
        ),
      ),
    );
  }
}
