import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A logged-in customer, backed by a doc in the top-level `customers`
/// collection (e.g. customers/cust_001) with fields:
/// email, password, Points, rating.
class Customer {
  Customer({
    required this.id,
    required this.name,
    required this.email,
    required this.password,
    required this.points,
    required this.rating,
    required this.loggedIn,
    required this.paymentCards,
    required this.photoUrl,
  });

  final String id;
  final String name;
  final String email;
  final String password;
  int points;
  double rating;
  final bool loggedIn;
  List<Map<String, dynamic>> paymentCards;
  final String? photoUrl;

  factory Customer.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? {};

    // Safely parse points whether Firestore stored it as int, double, or String
    int parsedPoints = 0;
    final rawPoints = data['Points'];
    if (rawPoints is num) {
      parsedPoints = rawPoints.toInt();
    } else if (rawPoints is String) {
      parsedPoints = int.tryParse(rawPoints) ?? 0;
    }

    final rawPaymentCards = data['paymentCards'];
    final paymentCards = <Map<String, dynamic>>[];
    if (rawPaymentCards is List) {
      for (final item in rawPaymentCards) {
        if (item is Map<String, dynamic>) {
          paymentCards.add(item);
        } else if (item is Map) {
          paymentCards.add(Map<String, dynamic>.from(item));
        }
      }
    }

    return Customer(
      id: doc.id,
      name: data['name'] as String? ?? 'HawkerGo User',
      email: data['email'] as String? ?? '',
      password: data['password'] as String? ?? '',
      points: parsedPoints,
      rating: (data['rating'] as num?)?.toDouble() ?? 0,
      loggedIn: data['loggedIn'] as bool? ?? false,
      paymentCards: paymentCards,
      photoUrl: data['photoUrl'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'password': password,
      'Points': points,
      'rating': rating,
      'loggedIn': loggedIn,
      'paymentCards': paymentCards,
    };
  }
}

class CustomerService extends ChangeNotifier {
  CustomerService._();

  static final CustomerService instance = CustomerService._();

  static const _lastLoginKey = 'last_logged_in_customer_id';

  final CollectionReference<Map<String, dynamic>> _customersRef =
      FirebaseFirestore.instance.collection('customers');

  Customer? _current;

  /// The currently active customer profile, or null if guest/not logged in.
  Customer? get current => _current;

  /// True if a customer session is loaded.
  bool get isLoggedIn => _current != null;

  /// Tries to re-login based on Firestore's `loggedIn` flag — this is the
  /// source of truth (not just whatever this device remembers), so if
  /// `loggedIn` is flipped to true directly in Firestore/console, the app
  /// will still pick it up and pull in the current name/email/Points.
  ///
  /// Returns true if auto-login succeeded.
  Future<bool> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedId = prefs.getString(_lastLoginKey);

    DocumentSnapshot<Map<String, dynamic>>? doc;

    // Fast path: if this device remembers a customer ID, confirm they're
    // still flagged loggedIn in Firestore before trusting it.
    if (savedId != null && savedId.isNotEmpty) {
      final savedDoc = await _customersRef.doc(savedId).get();
      if (savedDoc.exists && (savedDoc.data()?['loggedIn'] as bool? ?? false)) {
        doc = savedDoc;
      }
    }

    // Fallback: scan Firestore for whichever customer doc currently has
    // loggedIn: true. Covers a fresh device, or the flag being flipped
    // on directly in the Firebase console.
    if (doc == null) {
      final query = await _customersRef
          .where('loggedIn', isEqualTo: true)
          .limit(1)
          .get();

      if (query.docs.isEmpty) {
        await prefs.remove(_lastLoginKey);
        return false;
      }
      doc = query.docs.first;
    }

    // Pulls name, email, Points, rating, etc. straight from Firestore.
    _current = Customer.fromDoc(doc);
    await prefs.setString(_lastLoginKey, doc.id);

    notifyListeners();
    return true;
  }

  /// Refreshes the active customer object from Firestore so changes from other
  /// screens (e.g. settings updates) are picked up immediately.
  Future<void> refresh() async {
    if (_current == null) return;
    final doc = await _customersRef.doc(_current!.id).get();
    if (doc.exists) {
      _current = Customer.fromDoc(doc);
      notifyListeners();
    }
  }

  /// Adds [pointsEarned] to this customer's Points, locally and in
  /// Firestore, so it's remembered the next time they log in.
  Future<void> addPoints(int pointsEarned) async {
    if (_current == null) return;
    _current!.points += pointsEarned;
    notifyListeners();
    await _customersRef.doc(_current!.id).update({
      'Points': FieldValue.increment(pointsEarned),
    });
  }

  Future<void> deductPoints(int pointsToDeduct) async {
    if (_current == null) return;
    final int pointsUsed = min(pointsToDeduct, _current!.points);
    if (pointsUsed <= 0) return;

    _current!.points -= pointsUsed;
    notifyListeners();
    await _customersRef.doc(_current!.id).update({
      'Points': FieldValue.increment(-pointsUsed),
    });
  }

  /// Saves/updates a placed order under the test hawker profile orders path,
  /// while linking it to the current customer.
  Future<void> addOrderToHistory({
    required String orderId,
    required String title,
    required String subtitle,
    required String amount,
    required bool dinein,
    required List<String> dishNames,
    required String stallName,
  }) async {
    if (_current == null) return;
    await FirebaseFirestore.instance
        .collection('Hawker')
        .doc('test_hawker_001')
        .collection('profile')
        .doc('Profile')
        .collection('orders')
        .doc(orderId)
        .set({
          'customerId': _current!.id,
          'title': title,
          'subtitle': subtitle,
          'amount': amount,
          'dinein': dinein,
          'dishNames': dishNames,
          'stallName': stallName,
          'placedAt': Timestamp.now(),
          'status': 'preparing',
        }, SetOptions(merge: true));
  }

  /// Updates profile details in Firestore for the current user.
  Future<void> updateProfile({
    required String name,
    required String email,
  }) async {
    if (_current == null) return;
    await _customersRef.doc(_current!.id).update({
      'name': name,
      'email': email,
    });
    await refresh();
  }

  /// Stores a new payment card under the current customer record.
  Future<void> addPaymentCard({
    required String cardholderName,
    required String cardNumber,
    required String expiry,
  }) async {
    if (_current == null) return;

    final maskedNumber = cardNumber.replaceAll(RegExp(r'\D'), '');
    final last4 = maskedNumber.length >= 4
        ? maskedNumber.substring(maskedNumber.length - 4)
        : maskedNumber;
    final cardData = {
      'cardholderName': cardholderName,
      'cardNumber': '**** **** **** $last4',
      'expiry': expiry,
      'addedAt': Timestamp.now(),
    };

    await _customersRef.doc(_current!.id).set({
      'paymentCards': FieldValue.arrayUnion([cardData]),
    }, SetOptions(merge: true));

    _current!.paymentCards = List<Map<String, dynamic>>.from(
      _current!.paymentCards,
    )..add(cardData);
    notifyListeners();
  }

  /// Populates initial customer documents if the collection is empty.
  Future<void> seedSampleCustomersIfEmpty() async {
    final snapshot = await _customersRef.limit(1).get();
    if (snapshot.docs.isNotEmpty) return;

    final sampleCustomers = [
      {
        'id': 'cust_001',
        'name': 'Alex Tan',
        'email': 'alex.tan@gmail.com',
        'password': 'password123',
        'Points': 120,
        'rating': 4.8,
        'loggedIn': false,
      },
      {
        'id': 'cust_002',
        'name': 'Siti Nurhaliza',
        'email': 'siti.n@gmail.com',
        'password': 'password123',
        'Points': 50,
        'rating': 4.5,
        'loggedIn': false,
      },
    ];

    for (final cust in sampleCustomers) {
      final id = cust['id'] as String;
      final data = Map<String, dynamic>.from(cust)..remove('id');
      await _customersRef.doc(id).set(data);
    }
  }

  /// Logs in a user by matching email/password against Firestore docs.
  Future<bool> login(String email, String password) async {
    final query = await _customersRef
        .where('email', isEqualTo: email.trim())
        .where('password', isEqualTo: password.trim())
        .limit(1)
        .get();

    if (query.docs.isEmpty) return false;

    final doc = query.docs.first;
    _current = Customer.fromDoc(doc);
    await _customersRef.doc(doc.id).update({'loggedIn': true});

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_lastLoginKey, doc.id);

    notifyListeners();
    return true;
  }

  /// Logs out the current user session. Flushes whatever's currently held
  /// in memory (name/email/Points/rating/photoUrl) back to Firestore in
  /// the same write as flipping `loggedIn` to false, so nothing is lost
  /// even if a future change updates `_current` without going through
  /// updateProfile()/addPoints().
  Future<void> logout() async {
    if (_current != null) {
      await _customersRef.doc(_current!.id).set({
        'name': _current!.name,
        'email': _current!.email,
        'Points': _current!.points,
        'rating': _current!.rating,
        'photoUrl': FieldValue.delete(),
        'loggedIn': false,
      }, SetOptions(merge: true));
    }
    _current = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_lastLoginKey);
    notifyListeners();
  }
}
