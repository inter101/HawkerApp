import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';
import 'package:flutter_application_1/Real_Mad_project/notification_service.dart';


class PaymentSetupPage extends StatefulWidget {
  const PaymentSetupPage({super.key});

  @override
  State<PaymentSetupPage> createState() => _PaymentSetupPageState();
}

class _PaymentSetupPageState extends State<PaymentSetupPage> {
  final _formKey = GlobalKey<FormState>();
  final _cardNameController = TextEditingController();
  final _cardNumberController = TextEditingController();
  final _expiryController = TextEditingController();
  final _cvcController = TextEditingController();
  final _otpController = TextEditingController();

  bool _showVerification = false;
  bool _isSaving = false;
  String? _generatedOtp;

  @override
  void dispose() {
    _cardNameController.dispose();
    _cardNumberController.dispose();
    _expiryController.dispose();
    _cvcController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _addCard() async {
    if (!_formKey.currentState!.validate()) return;
    if (CustomerService.instance.current == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please log in before adding a card.')),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    final cardNumber = _cardNumberController.text.trim();
    final expiry = _expiryController.text.trim();
    final cardName = _cardNameController.text.trim();

    var shouldUpdate = true;
    try {
      await CustomerService.instance.addPaymentCard(
        cardholderName: cardName,
        cardNumber: cardNumber,
        expiry: expiry,
      );

      _generatedOtp = _createOtp();
      await NotificationService.instance.showOtpNotification(otp: _generatedOtp!);

      if (!mounted) {
        shouldUpdate = false;
      } else {
        setState(() {
          _showVerification = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Card saved. OTP sent via notification.')),
        );
      }
    } catch (error) {
      if (!mounted) {
        shouldUpdate = false;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Unable to save card: $error')),
        );
      }
    } finally {
      if (mounted && shouldUpdate) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }

  String _createOtp() {
    final random = Random();
    return List.generate(6, (_) => random.nextInt(10).toString()).join();
  }

  Widget _buildSavedCards() {
    final paymentCards = CustomerService.instance.current?.paymentCards ?? [];
    if (paymentCards.isEmpty) {
      return const Text(
        'No saved payment cards yet.',
        style: TextStyle(fontSize: 14, color: Colors.grey),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Saved cards',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        ...paymentCards.map((card) {
          final cardholderName = card['cardholderName'] as String? ?? 'Card holder';
          final cardNumber = card['cardNumber'] as String? ?? '**** **** **** ****';
          final expiry = card['expiry'] as String? ?? '';
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.black12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(cardNumber, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(cardholderName, style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 4),
                Text('Expiry: $expiry', style: const TextStyle(color: Colors.grey)),
              ],
            ),
          );
        }),
      ],
    );
  }

  Future<void> _verifyOtp() async {
    final enteredOtp = _otpController.text.trim();
    if (enteredOtp.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter the OTP from the notification.')),
      );
      return;
    }

    if (enteredOtp != _generatedOtp) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('OTP does not match. Please try again.')),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Verification successful. Returning to support page.')),
    );

    Navigator.pushNamedAndRemoveUntil(context, '/help_support', (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payments'),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        titleTextStyle: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold, fontSize: 20),
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Add a card to your account.',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'After adding the card, you will receive an OTP notification for verification.',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            _buildSavedCards(),
            const SizedBox(height: 24),
            if (!_showVerification) _buildCardForm(),
            if (_showVerification) _buildOtpForm(),
          ],
        ),
      ),
    );
  }

  Widget _buildCardForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextFormField(
            controller: _cardNameController,
            decoration: const InputDecoration(labelText: 'Cardholder name'),
            validator: (value) => value?.trim().isEmpty == true ? 'Enter the cardholder name' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _cardNumberController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Card number'),
            validator: (value) {
              final trimmed = value?.trim() ?? '';
              if (trimmed.isEmpty) return 'Enter a card number';
              if (trimmed.replaceAll(RegExp(r'\D'), '').length < 12) return 'Enter a valid card number';
              return null;
            },
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _expiryController,
                  keyboardType: TextInputType.datetime,
                  decoration: const InputDecoration(labelText: 'Expiry (MM/YY)'),
                  validator: (value) => value?.trim().isEmpty == true ? 'Enter expiry date' : null,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: TextFormField(
                  controller: _cvcController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'CVC'),
                  validator: (value) {
                    final trimmed = value?.trim() ?? '';
                    if (trimmed.isEmpty) return 'Enter CVC';
                    if (trimmed.length < 3) return 'Enter a valid CVC';
                    return null;
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: _isSaving ? null : _addCard,
            child: _isSaving
                ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('Add Card'),
          ),
        ],
      ),
    );
  }

  Widget _buildOtpForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Enter verification code',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        const Text(
          'A one-time password has been sent to your device notification center.',
          style: TextStyle(fontSize: 14, color: Colors.grey),
        ),
        const SizedBox(height: 24),
        TextField(
          controller: _otpController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'OTP code'),
        ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _verifyOtp,
          child: const Text('Verify OTP'),
        ),
      ],
    );
  }
}
