import 'package:flutter/material.dart';

class home extends StatelessWidget {
  const home({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
     color: const Color.fromARGB(255, 22, 187, 233),
child: const Center(
child: Column(children: [
SizedBox(height: 100),
Text(
"Profile page",
style: TextStyle(
fontSize: 30,
),
),
Text(
"Have fun updating the profile!",
style: TextStyle(fontSize: 20),
), ]), ),

    );
  }
}