import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/orderC.dart';

class orderstuff extends StatefulWidget {
  final Orderc order;
  final VoidCallback onCompleted;

  const orderstuff(this.order, {required this.onCompleted, super.key});

  @override
  State<orderstuff> createState() => _orderstuffState();
}

class _orderstuffState extends State<orderstuff> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 16, right: 16, bottom: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: kOrange, width: 2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          // ---------------- HEADER ----------------
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFC400),
                        shape: BoxShape.circle,
                      ),
                    ),

                    const SizedBox(width: 10),

                    Text(
                      '#${widget.order.ordernum}',
                      style: const TextStyle(fontSize: 24, color: Colors.black),
                    ),

                    const Spacer(),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFE8D4),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        widget.order.dinein ? 'Dine In' : 'Takeaway',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: kOrange,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                Row(
                  children: [
                    const Icon(
                      Icons.access_time,
                      size: 20,
                      color: Color(0xFF96969E),
                    ),

                    const SizedBox(width: 6),

                    Text(
                      widget.order.time.toDate().toString(),
                      style: const TextStyle(
                        fontSize: 14,
                        color: Color(0xFF96969E),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const Divider(height: 1, thickness: 2, color: Color(0xFFE0E0E0)),

          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 0, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: widget.order.ordersL.map((item) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      item.toString(),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          const Divider(height: 1, thickness: 2, color: Color(0xFFE0E0E0)),

          // ---------------- BOTTOM ----------------
          Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                // TOTAL
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Total',
                      style: TextStyle(fontSize: 14, color: Color(0xFF96969E)),
                    ),

                    const SizedBox(height: 3),

                    Text(
                      '\$ ${widget.order.totalp.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 24,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),

                const Spacer(),

                // ORDER DONE BUTTON
                ElevatedButton.icon(
                  onPressed: () async {
                    await databaseservice.updateCustomerOrderStatus(
                      widget.order.customerId,
                      widget.order.ordernum,
                    );
                    await databaseservice.addhistory(
                      widget.order.ordersL,
                      Timestamp.now(),
                      widget.order.totalp,
                      widget.order.dinein,
                      widget.order.ordernum,
                      widget.order.comment,
                      widget.order.customerId,
                    );
                    await databaseservice.removeOrderAt(
                      databaseservice.orderc.indexOf(widget.order),
                    );

                    widget.onCompleted();
                    setState(() {});
                  },
                  icon: const Icon(
                    Icons.check_circle_outline,
                    size: 20,
                    color: Colors.black,
                  ),
                  label: const Text(
                    'Done',
                    style: TextStyle(fontSize: 16, color: Colors.black),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kOrange,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 15,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
