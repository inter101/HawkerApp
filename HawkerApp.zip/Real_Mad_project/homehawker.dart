import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/orderC.dart';
import 'package:flutter_application_1/Real_Mad_project/qaz.dart';

class projectui extends StatefulWidget {
  const projectui({super.key});

  @override
  State<projectui> createState() => _projectuiState();
}

class _projectuiState extends State<projectui> {
  bool _showNewOrder = false;
  Timer? _notificationTimer;
  StreamSubscription? _orderSubscription;
  bool _firstSnapshot = true;

  @override
  void initState() {
    super.initState();

    databaseservice.getAllsettings().then((_) {
      setState(() {});
    });

    _listenForNewOrders();
  }

  void _listenForNewOrders() {
    _orderSubscription = databaseservice.order.snapshots().listen((snapshot) {
      if (_firstSnapshot) {
        _firstSnapshot = false;
        return;
      }

      for (final change in snapshot.docChanges) {
        if (change.type == DocumentChangeType.added) {
          _showOrderNotification();
        }
      }
    });
  }

  void _showOrderNotification() {
    _notificationTimer?.cancel();

    if (!mounted) return;

    setState(() {
      _showNewOrder = true;
    });

    _notificationTimer = Timer(const Duration(seconds: 10), () {
      if (!mounted) return;

      setState(() {
        _showNewOrder = false;
      });
    });
  }

  @override
  void dispose() {
    _orderSubscription?.cancel();
    _notificationTimer?.cancel();

    super.dispose();
  }

  double get totalRevenue {
    double total = 0;

    for (History h in databaseservice.historyList) {
      total += h.totalpH;
    }

    return total;
  }

  @override
  Widget build(BuildContext context) {
    bool pls = databaseservice.settings.isNotEmpty
        ? databaseservice.settings[0].status
        : false;
    return Scaffold(
      extendBody: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: kOrange,
        toolbarHeight: 130,
        surfaceTintColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        title: Row(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  'Dashboard',
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                ),

                SizedBox(height: 4),
                Row(
                  children: [
                    SizedBox(width: 8),
                    Text(
                      'Home',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: (pls) ? Color(0xFFD1F2E2) : Color(0xFFF5F5F5),
                    border: Border.all(
                      color: (pls) ? Colors.green : Colors.grey,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 4,
                        backgroundColor: (pls) ? Colors.green : Colors.grey,
                      ),
                      SizedBox(width: 5),
                      Text(
                        (pls) ? 'Open' : 'Closed',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: (pls) ? Colors.green : Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Container(
        color: Colors.white,
        alignment: Alignment.center,
        child: Column(
          children: [
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(width: 25),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${databaseservice.settings.isNotEmpty ? databaseservice.settings[0].stallname : ""}",
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 2.5),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${databaseservice.settings.isNotEmpty ? databaseservice.settings[0].stallnum : ""} ',
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 25),
              ],
            ),
            SizedBox(height: 20),

            Row(
              children: [
                SizedBox(width: 25),
                Expanded(
                  child: Container(
                    height: 75,
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: kOrange, width: 2),
                      color: Color(0xFFFFE8D4),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(width: 20),
                        Text(
                          "Revenue",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Spacer(),

                        Text(
                          "\$${totalRevenue.toStringAsFixed(2)}",
                          style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(width: 20),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 25),
              ],
            ),
            SizedBox(height: 25),

            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(width: 25),

                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: kOrange, width: 2),
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            SizedBox(width: 0),
                            Text(
                              'Orders done',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(width: 8),
                            Text(
                              '${databaseservice.gethistoryCount()}',
                              style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(width: 25),
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: kOrange, width: 2),
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            SizedBox(width: 0),
                            Text(
                              'Total orders',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(width: 8),
                            Text(
                              '${databaseservice.getorderCount()}',
                              style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(width: 25),
              ],
            ),
            SizedBox(height: 25),
            if (_showNewOrder)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25),
                child: InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, '/orderpage');
                  },
                  borderRadius: BorderRadius.circular(18),
                  child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                      color: kOrange,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(
                      children: [
                        const SizedBox(width: 20),

                        const Icon(
                          Icons.priority_high,
                          color: Colors.black,
                          size: 30,
                        ),

                        const SizedBox(width: 16),

                        const Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "A new order just came in!",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                "Tap to view",
                                style: TextStyle(
                                  color: Color(0xFFE8F8FF),
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const Icon(
                          Icons.chevron_right_rounded,
                          color: Colors.black,
                          size: 40,
                        ),

                        const SizedBox(width: 20),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),

      bottomNavigationBar: qaz(),
    );
  }
}
