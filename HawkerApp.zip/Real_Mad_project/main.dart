import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/account_settings_page.dart';
import 'package:flutter_application_1/Real_Mad_project/app_feedback_page.dart';
import 'package:flutter_application_1/Real_Mad_project/cart.dart';
import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/checkout_page.dart';
import 'package:flutter_application_1/Real_Mad_project/contact_support_page.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/help_support_page.dart';
import 'package:flutter_application_1/Real_Mad_project/history.dart';
import 'package:flutter_application_1/Real_Mad_project/history_page.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/homehawker.dart';
import 'package:flutter_application_1/Real_Mad_project/homepage.dart';
import 'package:flutter_application_1/Real_Mad_project/menu.dart';
import 'package:flutter_application_1/Real_Mad_project/notification_service.dart';
import 'package:flutter_application_1/Real_Mad_project/order.dart';
import 'package:flutter_application_1/Real_Mad_project/payment_setup_page.dart';
import 'package:flutter_application_1/Real_Mad_project/profile_page.dart';
import 'package:flutter_application_1/Real_Mad_project/rate_order_page.dart';
import 'package:flutter_application_1/Real_Mad_project/second_home.dart';
import 'package:flutter_application_1/Real_Mad_project/settings.dart';
import 'package:flutter_application_1/Real_Mad_project/stall.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // ...
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await databaseservice.getAllmenu();
  await databaseservice.getAllsettings();
  await databaseservice.getallorders();
  await databaseservice.getallhistory();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await NotificationService.instance.init();
  runApp(const MyApp());
  // Defer heavy network/bootstrap work so first frame renders quickly.
  unawaited(_bootstrapAppState());
}

Future<void> _bootstrapAppState() async {
  await CustomerService.instance.seedSampleCustomersIfEmpty();
  // If this device was already logged in before, restore that session
  // (and their saved order history) so they don't have to log in again
  // every time they open the app.
  final restoredSession = await CustomerService.instance.tryAutoLogin();
  // One-time cleanup requested: clear existing order history docs.
  final prefs = await SharedPreferences.getInstance();
  const orderHistoryPurgeKey = 'order_history_purged_once_v1';
  final didPurge = prefs.getBool(orderHistoryPurgeKey) ?? false;
  if (!didPurge) {
    await CartService.instance.clearOrderHistoryEverywhere();
    await prefs.setBool(orderHistoryPurgeKey, true);
  }
  if (restoredSession) {
    await CartService.instance.loadOrderHistoryFromFirestore();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HawkerGo',
      home: RoleSelectionScreen(),
      initialRoute: '/mainhome',

      routes: {
        '/mainhome': (context) => const RoleSelectionScreen(),
        '/homepage': (context) => const projectui(),
        '/orderpage': (context) => const order(),
        '/settings': (context) => const settings(),
        '/menu': (context) => const menu(),
        '/hawkerhistory': (context) => const history(),
        '/home': (context) => const SecondHome(),
        '/stalls': (context) => const Stall(),
        '/cart': (context) => const CartPage(),
        '/cushistory': (context) => const HistoryPage(),
        '/profile': (context) => const ProfilePage(),
        '/account_settings': (context) => const AccountSettingsPage(),
        '/help_support': (context) => const HelpSupportPage(),
        '/payment_setup': (context) => const PaymentSetupPage(),
        '/app_feedback': (context) => const AppFeedbackPage(),
        '/contact_support': (context) => const ContactSupportPage(),
        '/checkout': (context) => const CheckoutPage(),
        '/rate': (context) => const RateOrderPage(),
      },
    );
  }
}
