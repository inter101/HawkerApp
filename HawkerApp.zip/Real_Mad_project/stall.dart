import 'dart:async';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/points_badge.dart';
import 'package:flutter_application_1/Real_Mad_project/stall_detail_page.dart';

class Stall extends StatefulWidget {
  const Stall({super.key});

  @override
  State<Stall> createState() => _StallState();
}

class _StallState extends State<Stall> {
  int _headerFilterIndex = 0;

  final TextEditingController _searchController = TextEditingController();

  String _query = '';
  bool _showSearchBar = false;

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _hawkerSubscription;

  final Set<String> _favoriteStalls = {};
  final Set<String> _expandedStalls = {};

  final List<String> _headerFilters = [
    'All Category',
    'Cheapest',
    'Favourites',
  ];

  // ------------------------------------------------------------
  // FALLBACK STALLS
  // ------------------------------------------------------------

  final List<Map<String, dynamic>> _stalls = [];

  // ------------------------------------------------------------
  // FILTER
  // ------------------------------------------------------------

  List<Map<String, dynamic>> get _filteredStalls {
    List<Map<String, dynamic>> filtered = List.from(_stalls);

    if (_headerFilterIndex == 2) {
      filtered = filtered
          .where((stall) => _favoriteStalls.contains(stall['name'] as String))
          .toList();
    }

    if (_headerFilterIndex == 1) {
      filtered.sort(
        (a, b) => (a['averagePrice'] as double).compareTo(
          b['averagePrice'] as double,
        ),
      );
    }

    if (_query.isNotEmpty) {
      final keyword = _query.toLowerCase();

      filtered = filtered.where((stall) {
        final name = (stall['name'] as String? ?? '').toLowerCase();

        final category = (stall['category'] as String? ?? '').toLowerCase();

        final unitNo = (stall['unitNo'] as String? ?? '').toLowerCase();

        final menu = (stall['menu'] as List? ?? const []);

        final hasDishMatch = menu.any((dish) {
          if (dish is! Map) return false;

          final dishName = (dish['name'] as String? ?? '').toLowerCase();

          return dishName.contains(keyword);
        });

        return name.contains(keyword) ||
            category.contains(keyword) ||
            unitNo.contains(keyword) ||
            hasDishMatch;
      }).toList();
    }

    return filtered;
  }

  // ------------------------------------------------------------
  // INIT
  // ------------------------------------------------------------

  @override
  void initState() {
    super.initState();

    _loadAllHawkerStallsFromFirestore();
    _watchHawkerCollection();
  }

  @override
  void dispose() {
    _hawkerSubscription?.cancel();
    _searchController.dispose();

    super.dispose();
  }

  // ------------------------------------------------------------
  // WATCH FIRESTORE
  // ------------------------------------------------------------

  void _watchHawkerCollection() {
    _hawkerSubscription?.cancel();

    _hawkerSubscription = FirebaseFirestore.instance
        .collection('Hawker')
        .snapshots()
        .listen((snapshot) {
          if (!mounted) return;

          _loadAllHawkerStallsFromFirestore();
        });
  }

  // ------------------------------------------------------------
  // CONVERT TO DOUBLE
  // ------------------------------------------------------------

  double _toDouble(dynamic value, {double fallback = 0}) {
    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(value?.toString() ?? '') ?? fallback;
  }

  // ------------------------------------------------------------
  // CONVERT TO BOOL
  // ------------------------------------------------------------

  bool _toBool(dynamic value, {bool fallback = true}) {
    if (value is bool) {
      return value;
    }

    final text = value?.toString().trim().toLowerCase() ?? '';

    if (text == 'true' || text == '1' || text == 'yes' || text == 'open') {
      return true;
    }

    if (text == 'false' || text == '0' || text == 'no' || text == 'closed') {
      return false;
    }

    return fallback;
  }

  // ------------------------------------------------------------
  // LOAD ALL STALLS
  // ------------------------------------------------------------

  Future<void> _loadAllHawkerStallsFromFirestore() async {
    try {
      final localFallback = _stalls
          .map((stall) => Map<String, dynamic>.from(stall))
          .toList();

      final hawkerSnapshot = await FirebaseFirestore.instance
          .collection('Hawker')
          .get();

      if (hawkerSnapshot.docs.isEmpty) {
        return;
      }

      final List<Map<String, dynamic>> firebaseStalls = [];

      // --------------------------------------------------------
      // LOOP THROUGH HAWKERS
      // --------------------------------------------------------

      for (final hawkerDoc in hawkerSnapshot.docs) {
        final hawkerDocId = hawkerDoc.id;

        final profileRef = FirebaseFirestore.instance
            .collection('Hawker')
            .doc(hawkerDocId)
            .collection('profile')
            .doc('Profile');

        final profileSnapshot = await profileRef.get();

        final menuSnapshot = await profileRef.collection('Menu').get();

        final profileData = profileSnapshot.data() ?? <String, dynamic>{};

        final rootData = hawkerDoc.data();

        // ------------------------------------------------------
        // MENU
        // ------------------------------------------------------

        final List<Map<String, dynamic>> menuItems = menuSnapshot.docs.map((
          doc,
        ) {
          final data = doc.data();

          final double price = _toDouble(data['Price'] ?? data['price']);

          final bool available = _toBool(
            data['Stock'] ?? data['available'],
            fallback: true,
          );

          final String rawImage = (data['Image'] ?? data['imageUrl'] ?? '')
              .toString()
              .trim();

          return <String, dynamic>{
            'name': (data['DishName'] ?? data['name'] ?? 'Unnamed Dish')
                .toString(),

            'price': price,

            'stars': _toDouble(data['stars'] ?? data['rating'], fallback: 4.0),

            'available': available,

            // Menu picture filename
            'imageUrl': rawImage,
          };
        }).toList();

        // ------------------------------------------------------
        // CATEGORY
        // ------------------------------------------------------

        final String category =
            (profileData['category'] ??
                    rootData['category'] ??
                    (menuSnapshot.docs.isNotEmpty
                        ? menuSnapshot.docs.first.data()['Category']
                        : null) ??
                    'Mains')
                .toString();

        // ------------------------------------------------------
        // AVERAGE PRICE
        // ------------------------------------------------------

        final double averagePrice = menuItems.isNotEmpty
            ? menuItems
                      .map((item) => item['price'] as double)
                      .fold<double>(0, (acc, price) => acc + price) /
                  menuItems.length
            : _toDouble(
                profileData['averagePrice'] ?? rootData['averagePrice'],
              );

        // ------------------------------------------------------
        // STALL PICTURE
        //
        // Firestore:
        //
        // pic: "seven.png"
        //
        // Flutter:
        //
        // assets/images used/seven.png
        // ------------------------------------------------------

        final String stallPic = (profileData['pic'] ?? '').toString().trim();

        // ------------------------------------------------------
        // ADD STALL
        // ------------------------------------------------------

        firebaseStalls.add(<String, dynamic>{
          'docId': hawkerDocId,

          'name':
              (profileData['stallname'] ??
                      rootData['stallname'] ??
                      rootData['name'] ??
                      hawkerDocId)
                  .toString(),

          'category': category,

          'unitNo':
              (profileData['stallnum'] ??
                      rootData['stallnum'] ??
                      rootData['unitNo'] ??
                      '#00-00')
                  .toString(),

          'status': _toBool(
            profileData['status'] ?? rootData['status'],
            fallback: true,
          ),

          // IMPORTANT:
          // Store ONLY the filename.
          'imageUrl': stallPic,

          'stars': _toDouble(
            profileData['stars'] ?? rootData['stars'],
            fallback: 4,
          ).round().clamp(0, 5),

          'averagePrice': averagePrice,

          'menu': menuItems,
        });
      }

      if (firebaseStalls.isEmpty || !mounted) {
        return;
      }

      // --------------------------------------------------------
      // MERGE FALLBACK + FIRESTORE
      // --------------------------------------------------------

      setState(() {
        final seen = <String>{};

        String stallKey(Map<String, dynamic> stall) {
          final docId = (stall['docId'] ?? '').toString().trim().toLowerCase();

          if (docId.isNotEmpty) {
            return 'doc:$docId';
          }

          final name = (stall['name'] ?? '').toString().trim().toLowerCase();

          return 'name:$name';
        }

        final merged = <Map<String, dynamic>>[];

        final indexByKey = <String, int>{};

        // Add fallback
        for (final stall in localFallback) {
          final key = stallKey(stall);

          if (seen.add(key)) {
            indexByKey[key] = merged.length;

            merged.add(stall);
          }
        }

        // Replace with Firestore data
        for (final stall in firebaseStalls) {
          final key = stallKey(stall);

          if (indexByKey.containsKey(key)) {
            merged[indexByKey[key]!] = stall;
          } else if (seen.add(key)) {
            indexByKey[key] = merged.length;

            merged.add(stall);
          }
        }

        _stalls
          ..clear()
          ..addAll(merged);
      });
    } catch (e) {
      debugPrint('Error loading stalls: $e');

      // Keep fallback data
    }
  }

  // ------------------------------------------------------------
  // BUILD
  // ------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: double.infinity,
                  height: _showSearchBar ? 320 : 260,

                  child: Container(
                    padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),

                    decoration: const BoxDecoration(
                      color: Color.fromRGBO(243, 129, 27, 0.9),

                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(35),
                        bottomRight: Radius.circular(35),
                      ),
                    ),

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,

                          children: [
                            const Expanded(
                              child: Text(
                                'Find your Taste !!',
                                style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),

                            Row(
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,

                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                  ),

                                  child: IconButton(
                                    icon: const Icon(
                                      Icons.search,
                                      color: Colors.black87,
                                    ),

                                    onPressed: () {
                                      setState(() {
                                        _showSearchBar = !_showSearchBar;

                                        if (!_showSearchBar) {
                                          _searchController.clear();

                                          _query = '';
                                        }
                                      });
                                    },
                                  ),
                                ),

                                const SizedBox(width: 10),

                                Container(
                                  width: 44,
                                  height: 44,

                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.35),
                                    shape: BoxShape.circle,
                                  ),

                                  child: IconButton(
                                    icon: const Icon(
                                      Icons.notifications_none,
                                      color: Colors.black54,
                                    ),
                                    onPressed: () {},
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        const SizedBox(height: 5),

                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'Explore Food Stalls',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Color.fromRGBO(255, 255, 255, 0.9),
                                ),
                              ),
                            ),

                            const PointsBadge(),
                          ],
                        ),

                        const SizedBox(height: 15),

                        Wrap(
                          spacing: 10,
                          runSpacing: 10,

                          children: _headerFilters.map((filter) {
                            final index = _headerFilters.indexOf(filter);

                            final selected = _headerFilterIndex == index;

                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  _headerFilterIndex = index;
                                });
                              },

                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 10,
                                ),

                                decoration: BoxDecoration(
                                  color: selected
                                      ? const Color.fromRGBO(243, 129, 27, 0.9)
                                      : Colors.white,

                                  borderRadius: BorderRadius.circular(30),
                                ),

                                child: Text(
                                  filter,

                                  style: TextStyle(
                                    color: selected
                                        ? Colors.white
                                        : Colors.black,

                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),

                        if (_showSearchBar) ...[
                          const SizedBox(height: 12),

                          Container(
                            height: 46,

                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(24),
                            ),

                            child: TextField(
                              controller: _searchController,

                              onChanged: (value) {
                                setState(() {
                                  _query = value.trim();
                                });
                              },

                              decoration: const InputDecoration(
                                hintText: 'Search stalls or dishes...',

                                border: InputBorder.none,

                                prefixIcon: Icon(
                                  Icons.search,
                                  color: Colors.black54,
                                ),

                                contentPadding: EdgeInsets.symmetric(
                                  vertical: 12,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,

                children: [
                  const SizedBox(height: 10),

                  ..._filteredStalls.map(_buildStallCard),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),

      // --------------------------------------------------------
      // BOTTOM NAVIGATION
      // --------------------------------------------------------
      bottomNavigationBar: Container(
        margin: const EdgeInsets.only(left: 20, right: 20, bottom: 20),

        decoration: BoxDecoration(
          color: const Color.fromRGBO(243, 129, 27, 0.9),

          borderRadius: BorderRadius.circular(35),

          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.15),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),

        child: ClipRRect(
          borderRadius: BorderRadius.circular(35),

          child: BottomNavigationBar(
            backgroundColor: Colors.transparent,

            elevation: 0,

            type: BottomNavigationBarType.fixed,

            selectedIconTheme: const IconThemeData(
              color: Colors.white,
              size: 28,
            ),

            unselectedIconTheme: IconThemeData(
              color: Colors.white.withValues(alpha: 0.7),
              size: 28,
            ),

            selectedItemColor: Colors.white,

            unselectedItemColor: Colors.white.withValues(alpha: 0.7),

            selectedFontSize: 12,
            unselectedFontSize: 12,

            currentIndex: 1,

            onTap: (index) {
              if (index == 0) {
                Navigator.pushReplacementNamed(context, '/home');
              } else if (index == 1) {
              } else if (index == 2) {
                Navigator.pushReplacementNamed(context, '/cart');
              } else if (index == 3) {
                Navigator.pushReplacementNamed(context, '/history');
              } else if (index == 4) {
                Navigator.pushReplacementNamed(context, '/profile');
              }
            },

            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined, size: 28),
                label: 'Home',
              ),

              BottomNavigationBarItem(
                icon: Icon(Icons.storefront_outlined, size: 28),
                label: 'Stalls',
              ),

              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart_outlined, size: 28),
                label: 'Cart',
              ),

              BottomNavigationBarItem(
                icon: Icon(Icons.access_time_outlined, size: 28),
                label: 'History',
              ),

              BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, size: 28),
                label: 'Profile',
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // STALL CARD
  // ------------------------------------------------------------

  Widget _buildStallCard(Map<String, dynamic> stall) {
    final name = stall['name'] as String;

    final isFavorite = _favoriteStalls.contains(name);

    final stars = stall['stars'] as int;

    final isOpen = (stall['status'] as bool?) ?? true;

    final isExpanded = _expandedStalls.contains(name);

    final menu = (stall['menu'] as List? ?? const <Map<String, dynamic>>[])
        .cast<Map<String, dynamic>>();

    final String stallPic = (stall['imageUrl'] ?? '').toString().trim();

    return Container(
      margin: const EdgeInsets.only(bottom: 15),

      padding: const EdgeInsets.all(12),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius: BorderRadius.circular(20),

        border: Border.all(color: Colors.black12, width: 1.5),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,

        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,

            children: [
              // ------------------------------------------------
              // STALL PICTURE
              // ------------------------------------------------
              GestureDetector(
                onTap: () => _openStallDetail(stall),

                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),

                  child: stallPic.isEmpty
                      ? Container(
                          width: 70,
                          height: 70,
                          color: Colors.grey.shade200,
                          child: const Icon(
                            Icons.store,
                            color: Colors.grey,
                            size: 35,
                          ),
                        )
                      : Image.asset(
                          'assets/images used/$stallPic',

                          width: 70,
                          height: 70,

                          fit: BoxFit.cover,

                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              width: 70,
                              height: 70,
                              color: Colors.grey.shade200,
                              child: const Icon(
                                Icons.broken_image,
                                color: Colors.grey,
                              ),
                            );
                          },
                        ),
                ),
              ),

              const SizedBox(width: 15),

              // ------------------------------------------------
              // STALL INFORMATION
              // ------------------------------------------------
              Expanded(
                child: GestureDetector(
                  onTap: () => _openStallDetail(stall),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text(
                        name,

                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),

                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),

                      const SizedBox(height: 2),

                      Text(
                        '${stall['category'] as String} • ${stall['unitNo'] as String}',

                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),

                      const SizedBox(height: 6),

                      Row(
                        children: [
                          Text(
                            '\$${(stall['averagePrice'] as double).toStringAsFixed(2)}',

                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.black45,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(width: 10),

                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 1,
                            ),

                            decoration: BoxDecoration(
                              color: isOpen
                                  ? Colors.green.shade100
                                  : Colors.red.shade100,

                              borderRadius: BorderRadius.circular(8),
                            ),

                            child: Text(
                              isOpen ? 'Open' : 'Closed',

                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: isOpen
                                    ? Colors.green.shade700
                                    : Colors.red.shade700,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 4),

                      Row(
                        children: List.generate(5, (index) {
                          return Icon(
                            index < stars ? Icons.star : Icons.star_border,

                            size: 14,

                            color: index < stars
                                ? Colors.amber
                                : Colors.grey.shade400,
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              ),

              // ------------------------------------------------
              // FAVOURITE / EXPAND
              // ------------------------------------------------
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,

                children: [
                  IconButton(
                    icon: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,

                      color: isFavorite ? Colors.red : Colors.grey,
                    ),

                    onPressed: () {
                      setState(() {
                        if (isFavorite) {
                          _favoriteStalls.remove(name);
                        } else {
                          _favoriteStalls.add(name);
                        }
                      });
                    },
                  ),

                  IconButton(
                    icon: Icon(
                      isExpanded
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,

                      size: 28,
                      color: Colors.black87,
                    ),

                    onPressed: () {
                      setState(() {
                        if (isExpanded) {
                          _expandedStalls.remove(name);
                        } else {
                          _expandedStalls.add(name);
                        }
                      });
                    },
                  ),
                ],
              ),
            ],
          ),

          // ----------------------------------------------------
          // EXPANDED MENU
          // ----------------------------------------------------
          if (isExpanded) ...[
            const Padding(
              padding: EdgeInsets.only(top: 10, bottom: 4),

              child: Text(
                'Menu:',

                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
              ),
            ),

            if (menu.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),

                child: Text(
                  'No menu uploaded yet',

                  style: TextStyle(color: Colors.black45),
                ),
              )
            else
              for (final dish in menu.take(2)) _buildMiniMenuRow(stall, dish),

            const SizedBox(height: 8),

            SizedBox(
              width: double.infinity,

              child: TextButton.icon(
                onPressed: () => _openStallDetail(stall),

                style: TextButton.styleFrom(
                  backgroundColor: const Color.fromRGBO(255, 238, 215, 1),

                  padding: const EdgeInsets.symmetric(vertical: 10),

                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),

                icon: const Icon(
                  Icons.restaurant_menu,
                  size: 18,
                  color: Color.fromRGBO(243, 129, 27, 1),
                ),

                label: const Text(
                  'View Full Menu',

                  style: TextStyle(
                    color: Color.fromRGBO(243, 129, 27, 1),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // MINI MENU
  // ------------------------------------------------------------

  Widget _buildMiniMenuRow(
    Map<String, dynamic> stall,
    Map<String, dynamic> dish,
  ) {
    final dishName = dish['name'] as String;

    final price = dish['price'] as double;

    final available = dish['available'] as bool? ?? true;

    final isOpen = (stall['status'] as bool?) ?? true;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),

      child: Row(
        children: [
          // Menu images still use
          // whatever filename is stored
          // in the Menu document.
          ClipRRect(
            borderRadius: BorderRadius.circular(10),

            child: Image.asset(
              'assets/images used/${dish['imageUrl'] ?? ''}',

              width: 40,
              height: 40,

              fit: BoxFit.cover,

              errorBuilder: (context, error, stackTrace) {
                return Container(
                  width: 40,
                  height: 40,
                  color: Colors.grey.shade200,
                  child: const Icon(Icons.image, color: Colors.grey, size: 20),
                );
              },
            ),
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  dishName,

                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),

                Text(
                  '\$${price.toStringAsFixed(2)}',

                  style: const TextStyle(
                    color: Color.fromRGBO(243, 129, 27, 1),
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),

          IconButton(
            icon: Icon(
              Icons.add_circle,

              color: (available && isOpen)
                  ? const Color.fromRGBO(243, 129, 27, 1)
                  : Colors.grey.shade300,
            ),

            onPressed: (available && isOpen)
                ? () => _addDishToCart(stall, dish)
                : null,
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // ADD TO CART
  // ------------------------------------------------------------

  void _addDishToCart(Map<String, dynamic> stall, Map<String, dynamic> dish) {
    final stallName = stall['name'] as String;

    final stallDocId = (stall['docId'] ?? '').toString();

    final dishName = dish['name'] as String;

    final price = dish['price'] as double;

    final available = dish['available'] as bool? ?? true;

    try {
      CartService.instance.addItem(
        CartItem(
          id: '$stallName-$dishName',
          name: dishName,
          stall: stallName,
          stallDocId: stallDocId,
          price: price,
          available: available,
        ),
      );

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Added $dishName to cart'),
          duration: const Duration(seconds: 1),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  // ------------------------------------------------------------
  // OPEN STALL DETAIL
  // ------------------------------------------------------------

  void _openStallDetail(Map<String, dynamic> stall) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => StallDetailPage(stall: stall)),
    );
  }
}
