import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';
import 'package:flutter_application_1/Real_Mad_project/points_badge.dart';


class AccountSettingsPage extends StatefulWidget {
  const AccountSettingsPage({super.key});

  @override
  State<AccountSettingsPage> createState() => _AccountSettingsPageState();
}

class _AccountSettingsPageState extends State<AccountSettingsPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final FocusNode _nameFocus = FocusNode();
  final FocusNode _emailFocus = FocusNode();
  bool _notificationsEnabled = true;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _loadCustomer();
    CustomerService.instance.addListener(_onCustomerChanged);
  }

  Future<void> _loadCustomer() async {

    await CustomerService.instance.refresh();
    final customer = CustomerService.instance.current;
    if (!mounted) return;
    if (customer != null) {
      setState(() {
        _nameController.text = customer.name;
        _emailController.text = customer.email;
      });
    } else {
      setState(() {
        _nameController.text = 'Guest User';
        _emailController.text = 'guest@hawkergo.com';
      });
    }
  }

  void _onCustomerChanged() {
    final customer = CustomerService.instance.current;
    if (!mounted) return;
    
    if (!_nameFocus.hasFocus && !_emailFocus.hasFocus) {
      if (customer != null) {
        setState(() {
          _nameController.text = customer.name;
          _emailController.text = customer.email;
        });
      }
    }
  }

  @override
  void dispose() {
    CustomerService.instance.removeListener(_onCustomerChanged);
    _nameFocus.dispose();
    _emailFocus.dispose();
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          'Account Settings',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Center(child: PointsBadge()),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Update your profile and notification preferences.',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 30),
            const Text('Name', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                hintText: 'Enter your name',
              ),
            ),
            const SizedBox(height: 20),
            const Text('Email', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                hintText: 'Enter your email',
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Expanded(
                  child: Text(
                    'Order notifications',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Switch(
                  value: _notificationsEnabled,
                  activeThumbColor: Colors.orange.shade900,
                  activeTrackColor: Colors.orange.shade200,
                  onChanged: (value) => setState(() => _notificationsEnabled = value),
                ),
              ],
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromRGBO(243, 129, 27, 1),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                onPressed: _isSaving
                    ? null
                    : () async {
                        setState(() => _isSaving = true);
                        final messenger = ScaffoldMessenger.of(context);
                        final name = _nameController.text.trim();
                        final email = _emailController.text.trim();
                        try {
                          await CustomerService.instance.updateProfile(name: name, email: email);
                          if (!mounted) return;
                          messenger.showSnackBar(
                            const SnackBar(content: Text('Account settings saved.')),
                          );
                        } catch (e) {
                          if (!mounted) return;
                          messenger.showSnackBar(
                            SnackBar(content: Text('Could not save settings: $e')),
                          );
                        } finally {
                          if (mounted) setState(() => _isSaving = false);
                        }
                      },
                child: _isSaving
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                        'Save Settings',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}