import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';




class RegisterStallScreen extends StatefulWidget {
  const RegisterStallScreen({super.key});

  @override
  State<RegisterStallScreen> createState() => _RegisterStallScreenState();
}

class _RegisterStallScreenState extends State<RegisterStallScreen> {
  bool _showPassword = false;
  bool _loading = false;
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _stallNameController = TextEditingController();
  final _unitNumberController = TextEditingController();

  bool get _isFormFilled =>
      _emailController.text.trim().isNotEmpty &&
      _passwordController.text.trim().isNotEmpty &&
      _stallNameController.text.trim().isNotEmpty &&
      _unitNumberController.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    _emailController.addListener(() => setState(() {}));
    _passwordController.addListener(() => setState(() {}));
    _stallNameController.addListener(() => setState(() {}));
    _unitNumberController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _stallNameController.dispose();
    _unitNumberController.dispose();
    super.dispose();
  }

  Future<void> _createStallAccount() async {
    setState(() => _loading = true);
    await databaseservice.registerHawker(
      _emailController.text,
      _passwordController.text,
      _stallNameController.text,
  '#${_unitNumberController.text}',
    );
    setState(() => _loading = false);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Stall account created! Please sign in.')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            TextButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.chevron_left, color: Colors.grey),
              label: const Text('Back to Sign In', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: kOrange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.storefront_outlined, color: kOrange, size: 32),
            ),
            const SizedBox(height: 20),
            const Text('Register Your Stall', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('These details can be updated anytime after sign-in', style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 28),
            const Text('EMAIL ADDRESS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                hintText: 'stall@email.com',
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: const Icon(Icons.email_outlined),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            const Text('PASSWORD', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _passwordController,
              obscureText: !_showPassword,
              decoration: InputDecoration(
                hintText: 'At least 6 characters',
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: IconButton(
                  icon: Icon(_showPassword ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _showPassword = !_showPassword),
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            const Text('STALL NAME', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _stallNameController,
              decoration: InputDecoration(
                hintText: 'e.g. Ah Chow Chicken Rice',
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: const Icon(Icons.restaurant),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            const Text('UNIT NUMBER', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _unitNumberController,
              decoration: InputDecoration(
                hintText: 'e.g. 01-08',
                prefixText: '# ',
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: const Icon(Icons.location_on_outlined),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: (_isFormFilled && !_loading) ? _createStallAccount : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isFormFilled ? kOrange : kOrange.withOpacity(0.5),
                  disabledBackgroundColor: kOrange.withOpacity(0.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _loading
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Create Stall Account', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
          ],
        ),
    );
  }
}