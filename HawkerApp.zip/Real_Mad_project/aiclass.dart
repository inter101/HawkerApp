import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiService {
  static const String apiKey =
      'AQ.Ab8RN6IHfmqG3Xr9zD5K3Hnxx7boP7yQudEUdru8KbrQE5IVPA';

  static final GenerativeModel model = GenerativeModel(
    model: 'gemini-3.5-flash',
    apiKey: apiKey,
  );

  static Future<String> askGemini(String prompt) async {
    final response = await model.generateContent([Content.text(prompt)]);

    return response.text ?? 'No response';
  }
}
