import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';

class qaz extends StatefulWidget {
  const qaz({super.key});

  @override
  State<qaz> createState() => _qazState();
}

class _qazState extends State<qaz> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 65,
      margin: const EdgeInsets.only(right: 24, left: 24, bottom: 24),
      decoration: BoxDecoration(
        color: kOrange,
        borderRadius: BorderRadius.circular(50),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(20),
            blurRadius: 20,
            spreadRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/homepage');

              setState(() {});
            },
            color: Colors.white,
            icon: Icon(Icons.home),
          ),

          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/orderpage');
            },
            color: Colors.white,
            icon: Icon(Icons.menu_book),
          ),

          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/menu');
            },
            color: Colors.white,
            icon: Icon(Icons.food_bank),
          ),

          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/hawkerhistory');
            },
            color: Colors.white,
            icon: Icon(Icons.history),
          ),

          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/settings');

              setState(() {});
            },
            color: Colors.white,
            icon: Icon(Icons.settings),
          ),
        ],
      ),
    );
  }
}
