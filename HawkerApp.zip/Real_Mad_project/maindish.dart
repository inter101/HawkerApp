import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/Menuitem.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
//individual page for the widget I want to make a list of

class menuwidget extends StatefulWidget {
  final String category;
  final int index;
  final VoidCallback onDelete;
  final VoidCallback onStockChanged;
  const menuwidget({
    super.key,
    required this.category,
    required this.index,
    required this.onDelete,
    required this.onStockChanged,
  });

  @override
  State<menuwidget> createState() => _menuwidgetState();
}

class _menuwidgetState extends State<menuwidget> {
  bool plax = true;

  MenuItem get item {
    return databaseservice.getCategorymenu(widget.category, widget.index);
  }

  @override
  Widget build(BuildContext context) {
    void test() async {
      plax = !plax;
      item.stock = plax;
      await databaseservice.updatestock(item.name, item.stock);
      widget.onStockChanged();
      setState(() {});
    }

    return Padding(
      padding: EdgeInsets.fromLTRB(0, 10, 0, 20),

      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              border: Border.all(
                color: (item.stock) ? kOrange : Color(0xFFFFE99C),

                width: 2,
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            padding: EdgeInsets.all(10),

            child: Row(
              children: [
                SizedBox(width: 5),
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),

                  child: Image.asset(
                    'assets/images used/${item.image}',
                    width: 60,
                    height: 60,
                  ),
                ),
                SizedBox(width: 10),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5),

                    Text(
                      '\$ ${item.price}',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Spacer(),
                FilledButton(
                  onPressed: test,
                  style: FilledButton.styleFrom(
                    backgroundColor: Color(0xFFFFF7DE),
                    side: const BorderSide(color: kOrange, width: 2),
                    minimumSize: const Size(0, 45),
                    padding: EdgeInsets.fromLTRB(10, 20, 10, 20),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child: Text(
                      (item.stock) ? 'Out of stock' : 'Back in stock',
                      style: TextStyle(
                        color: kOrange,
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 5),
                FilledButton(
                  onPressed: () async {
                    await databaseservice.deleteMenuItem(item.name);
                    widget.onDelete();
                    widget.onStockChanged();
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: Color(0xFFFFC2C3),
                    side: const BorderSide(color: Colors.red, width: 2),
                    minimumSize: const Size(0, 45),
                    padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child: Icon(
                      Icons.clear,
                      color: Colors.red,
                      weight: 10,
                      size: 35,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (!item.stock)
            Positioned(
              top: -14,
              left: 20,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Color(0xFFFFE99C),
                  border: Border.all(color: Color(0xFFFFE8D4)),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Text(
                  'out of stock',
                  style: TextStyle(
                    color: kOrange,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
