import 'dart:async';

// ignore: file_names
import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';
import 'package:flutter_application_1/Real_Mad_project/profile_page.dart';
import 'package:flutter_application_1/Real_Mad_project/second_home.dart';


class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Welcome Back !',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20), // ads a space
              Image.asset('assets/logo.png', width: 300, height: 300),
              const SizedBox(height: 20), // adds a space
              const Text(
                'HawkerGo',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 40), // adds a space
              SizedBox(
                height: 60,
                width: 280,
                child: ElevatedButton(
                  onPressed: () async {
                    bool loggedIn = false;
                    try {
                      loggedIn = await CustomerService.instance
                          .tryAutoLogin()
                          .timeout(
                            const Duration(seconds: 6),
                            onTimeout: () => false,
                          );

                      if (loggedIn) {
                        // Do not block navigation on slow history fetch.
                        unawaited(
                          CartService.instance.loadOrderHistoryFromFirestore(),
                        );
                      } else {
                        await CustomerService.instance.logout();
                      }
                    } catch (_) {
                      loggedIn = false;
                    }

                    if (!context.mounted) return;
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            loggedIn ? const ProfilePage() : const SecondHome(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromRGBO(243, 129, 27, 9),

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 5,
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Let\'s Go',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(width: 10), // adds a space
                      Icon(Icons.arrow_forward, color: Colors.black),
                    ],
                  ),
                ),
              ), // adds a space
            ], // children
          ),
        ),
      ),
    ); // scaffold
  } // widget build
}// class home page