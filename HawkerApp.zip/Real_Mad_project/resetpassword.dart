import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';


import 'custfirebase.dart';

import 'resetting_password.dart';

class ResetPasswordScreen extends StatefulWidget {
  final bool isHawker;
  const ResetPasswordScreen({super.key, required this.isHawker});

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final _emailController = TextEditingController();
  bool _loading = false;

  bool get _isFormFilled => _emailController.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    _emailController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _checkEmail() async {
    setState(() => _loading = true);
    bool exists = widget.isHawker
        ? await databaseservice.checkHawkerEmailExists(_emailController.text)
        : await Custfirebase.checkCustomerEmailExists(_emailController.text);
    setState(() => _loading = false);
    if (!mounted) return;

    if (exists) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResettingPasswordScreen(email: _emailController.text, isHawker: widget.isHawker),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No account found with that email')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            TextButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.chevron_left, color: Colors.grey),
              label: const Text('Back to Sign In', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: kOrange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.lock_open, color: kOrange, size: 32),
            ),
            const SizedBox(height: 20),
            const Text('Reset Password', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('Enter your email and we will send a reset link', style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 28),
            const Text('EMAIL ADDRESS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                hintText: 'your@email.com',
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: const Icon(Icons.email_outlined),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: (_isFormFilled && !_loading) ? _checkEmail : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isFormFilled ? kOrange : kOrange.withOpacity(0.5),
                  disabledBackgroundColor: kOrange.withOpacity(0.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _loading
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Continue', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
          ],
        ),
    );
  }
}