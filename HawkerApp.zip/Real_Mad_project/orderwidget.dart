import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/orderzstuff.dart';

class orderwidget extends StatefulWidget {
  final VoidCallback onOrdersChanged;

  const orderwidget({super.key, required this.onOrdersChanged});

  @override
  State<orderwidget> createState() => _orderwidgetState();
}

class _orderwidgetState extends State<orderwidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(0, 0, 0, 30),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 25),
            SizedBox(
              child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: databaseservice.getorderCount(),
                itemBuilder: (context, index) {
                  return orderstuff(
                    databaseservice.getorderAt(index),
                    onCompleted: () {
                      widget.onOrdersChanged();
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
