import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';

const List<String> _navRoutes = [
  '/home',
  '/stalls',
  '/cart',
  '/cushistory',
  '/profile',
];

Widget buildAppBottomNav(BuildContext context, int currentIndex) {
  return AnimatedBuilder(
    animation: CustomerService.instance,
    builder: (context, _) {

      return SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: Container(
        height: 72,
        decoration: BoxDecoration(
          color: const Color.fromRGBO(243, 129, 27, 0.95),
          borderRadius: BorderRadius.circular(35),
          boxShadow: [
            const BoxShadow(
              color: Color.fromRGBO(0, 0, 0, 0.15),
              blurRadius: 10,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(35),
          child: BottomNavigationBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            type: BottomNavigationBarType.fixed,
            selectedItemColor: Colors.black,
            unselectedItemColor: Colors.black87,
            selectedFontSize: 12,
            unselectedFontSize: 12,
            currentIndex: currentIndex,
            onTap: (index) {
              if (index == currentIndex) return;
              Navigator.pushReplacementNamed(context, _navRoutes[index]);
            },
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined, size: 28),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.storefront_outlined, size: 28),
                label: 'Stalls',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart_outlined, size: 28),
                label: 'Cart',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.access_time_outlined, size: 28),
                label: 'History',
              ),
              const BottomNavigationBarItem(
                icon: Icon(Icons.person_outline, size: 28),
                label: 'Profile',
              ),
            ],
          ),
        ),
      ),
    ),
      );
    },
  );
}
