import 'package:cloud_firestore/cloud_firestore.dart';

class Orderc {
  List ordersL;
  Timestamp time;
  double totalp;
  bool dinein;
  int ordernum;
  String customerId;
  String comment;
  String status;
  Orderc(
    this.ordersL,
    this.time,
    this.totalp,
    this.dinein,
    this.ordernum,
    this.customerId,
    this.comment,
    this.status,
  );
}

class History {
  List ordersH;
  Timestamp timeH;
  double totalpH;
  bool dineinH;
  int ordernumH;
  String review;
  String customerId;
  History(
    this.ordersH,
    this.timeH,
    this.totalpH,
    this.dineinH,
    this.ordernumH,
    this.review,
    this.customerId,
  );
}
