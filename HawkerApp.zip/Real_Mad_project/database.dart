import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_application_1/Real_Mad_project/Menuitem.dart';
import 'package:flutter_application_1/Real_Mad_project/Usettings.dart';
import 'package:flutter_application_1/Real_Mad_project/orderC.dart';

class databaseservice {
  static final FirebaseFirestore db = FirebaseFirestore.instance;
  static final FirebaseAuth auth = FirebaseAuth.instance;
  static final CollectionReference hawkers = FirebaseFirestore.instance
      .collection('Hawker');

  static List<MenuItem> menuitem = [];
  static List<Usettings> settings = [];
  static List<Orderc> orderc = [];
  static List<History> historyList = [];
  static String? tawkerId;

  static Future<String> _generateNextHawkerId() async {
    QuerySnapshot snapshot = await hawkers.get();
    int nextNumber = snapshot.docs.length + 1;
    return 'hawker_${nextNumber.toString().padLeft(3, '0')}';
  }

  static Future<void> registerHawker(
    String email,
    String password,
    String stallName,
    String stallNumber,
  ) async {
    String hawkerId = await _generateNextHawkerId();

    await hawkers.doc(hawkerId).set({'email': email, 'password': password});

    await hawkers.doc(hawkerId).collection('profile').doc('Profile').set({
      'stallname': stallName,
      'stallnum': stallNumber,
      'status': false,
    });
  }

  static Future<bool> loginHawker(String email, String password) async {
    QuerySnapshot qs = await hawkers
        .where('email', isEqualTo: email)
        .where('password', isEqualTo: password)
        .limit(1)
        .get();
    if (qs.docs.isEmpty) return false;

    tawkerId = qs.docs.first.id;

    return true;
  }

  static Future<bool> checkHawkerEmailExists(String email) async {
    QuerySnapshot qs = await hawkers
        .where('email', isEqualTo: email)
        .limit(1)
        .get();
    return qs.docs.isNotEmpty;
  }

  static Future updateStallPic(String newPic) async {
    await profile.set({'pic': newPic}, SetOptions(merge: true));
  }

  static Future<void> updateHawkerPassword(
    String email,
    String newPassword,
  ) async {
    QuerySnapshot qs = await hawkers
        .where('email', isEqualTo: email)
        .limit(1)
        .get();
    if (qs.docs.isNotEmpty) {
      await qs.docs.first.reference.update({'password': newPassword});
    }
  }

  static String testHawkerId = "test_hawker_001";
  static int getCountmenu() {
    return (menuitem.length);
  }

  static String get userId {
    return auth.currentUser?.uid ?? testHawkerId;
  }

  static DocumentReference get hawker {
    return db.collection(tawkerId ?? "test_hawker_001").doc(userId);
  }

  static DocumentReference get profile => FirebaseFirestore.instance
      .collection('Hawker')
      .doc(tawkerId)
      .collection('profile')
      .doc('Profile');

  static CollectionReference get menu => FirebaseFirestore.instance
      .collection('Hawker')
      .doc(tawkerId)
      .collection('profile')
      .doc('Profile')
      .collection('Menu');

  static CollectionReference get order => FirebaseFirestore.instance
      .collection('Hawker')
      .doc(tawkerId)
      .collection('profile')
      .doc('Profile')
      .collection('order');

  static CollectionReference get history => FirebaseFirestore.instance
      .collection('Hawker')
      .doc(tawkerId)
      .collection('profile')
      .doc('Profile')
      .collection('history');

  static Future<void> addMenuItem(
    String name,
    double price,
    String category,
    String image,
    bool stock,
  ) async {
    await menu.add({
      'DishName': name,
      'Price': price,
      'Category': category,
      'Image': image,
      'Stock': stock,
    });

    menuitem.add(MenuItem(name, price, category, image, stock));
  }

  static Future<void> getAllmenuitem() async {
    menuitem.clear();

    QuerySnapshot snapshot = await menu.get();

    for (var doc in snapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

      menuitem.add(
        MenuItem(
          data['DishName'],
          (data['Price'] as num).toDouble(),
          data['Category'],
          data['Image'],
          data['Stock'],
        ),
      );
    }
  }

  static MenuItem getCategorymenu(String category, int index) {
    return menuitem.where((item) => item.category == category).toList()[index];
  }

  static int getCategoryCount(String category) {
    return menuitem.where((item) => item.category == category).length;
  }

  static Future<void> deleteMenuItem(String name) async {
    QuerySnapshot snapshot = await menu
        .where('DishName', isEqualTo: name)
        .get();

    if (snapshot.docs.isEmpty) {
      return;
    }

    String documentId = snapshot.docs.first.id;

    await menu.doc(documentId).delete();

    menuitem.removeWhere((item) => item.name == name);
  }

  static Future<Map<String, dynamic>?> getProfileData() async {
    DocumentSnapshot doc = await profile.get();
    if (!doc.exists) {
      return null;
    }
    return doc.data() as Map<String, dynamic>?;
  }

  static MenuItem getMenuAt(int index) {
    return (menuitem[index]);
  }

  static Future<void> updateStallName(String newName) async {
    await profile.set({'stallname': newName}, SetOptions(merge: true));
  }

  static Future<void> updateStallNum(String newNum) async {
    await profile.set({'stallnum': newNum}, SetOptions(merge: true));
  }

  static Future<void> updateStatus(bool newStatus) async {
    await profile.set({'status': newStatus}, SetOptions(merge: true));
  }

  static Future<void> getAllmenu() async {
    print('Starting menu loading');
    menuitem.clear();

    QuerySnapshot qs = await menu.get();
    print('Firestore finished loading');
    for (int i = 0; i < qs.docs.length; i++) {
      DocumentSnapshot doc = qs.docs[i];
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      menuitem.add(
        MenuItem(
          data['DishName'],
          (data['Price'] as num).toDouble(),
          data['Category'],
          data['Image'],
          data['Stock'],
        ),
      );
    }
    print('Total menu items: ${menuitem.length}');
  }

  static int getOutOfStockCount() {
    return menuitem.where((item) => !item.stock).length;
  }

  static Future<void> updatestock(String name, bool newstock) async {
    QuerySnapshot snapshot = await menu
        .where('DishName', isEqualTo: name)
        .get();

    if (snapshot.docs.isEmpty) return;

    String documentId = snapshot.docs.first.id;
    await menu.doc(documentId).update({'Stock': newstock});
  }

  static Future<void> getAllsettings() async {
    settings.clear();
    print(profile.path);
    DocumentSnapshot qs = await profile.get();

    if (!qs.exists) {
      print('Profile document does not exist');
      return;
    }
    Map<String, dynamic> data = qs.data() as Map<String, dynamic>;
    settings.add(
      Usettings(
        data['stallname'],
        data['stallnum'],
        data['status'],
        data['pic'] ?? '',
      ),
    );
  }

  static int getorderCount() {
    return (orderc.length);
  }

  static int gethistoryCount() {
    return (historyList.length);
  }

  static Orderc getorderAt(int index) {
    return (orderc[index]);
  }

  static Future<void> getallorders() async {
    orderc.clear();

    QuerySnapshot qs = await order.get();

    for (int i = 0; i < qs.docs.length; i++) {
      DocumentSnapshot doc = qs.docs[i];
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      orderc.add(
        Orderc(
          data['ordersL'],
          data['time'],
          (data['totalp'] as num).toDouble(),
          data['dinein'],
          data['ordernum'],
          data['customerId'] ?? '',
          data['comment'] ?? '',
          data['status'] ?? 'preparing',
        ),
      );
    }
  }

  static Future<void> removeOrderAt(int index) async {
    int idToDelete = orderc[index].ordernum;
    orderc.removeAt(index);
    QuerySnapshot qs = await order
        .limit(1)
        .where("ordernum", isEqualTo: idToDelete)
        .get();
    DocumentSnapshot doc = qs.docs[0];
    doc.reference.delete();
  }

  static Future<void> addhistory(
    List ordersH,
    Timestamp timeH,
    double totalpH,
    bool dineinH,
    int ordernumH,
    String review,
    String customerId,
  ) async {
    historyList.add(
      History(ordersH, timeH, totalpH, dineinH, ordernumH, review, customerId),
    );

    final DocumentReference dr = await history.add({
      'ordersH': ordersH,
      'timeH': timeH,
      'totalpH': totalpH,
      'dineinH': dineinH,
      'ordernumH': ordernumH,
      'review': review,
      'customerId': customerId,
    });
  }

  static Future updateCustomerOrderStatus(
    String customerId,
    int ordernum,
  ) async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('customers')
        .doc(customerId)
        .collection('orderHistory')
        .where('ordernum', isEqualTo: ordernum)
        .limit(1)
        .get();

    if (snapshot.docs.isNotEmpty) {
      await snapshot.docs.first.reference.update({'status': 'served'});
    }
  }

  static Future<void> getallhistory() async {
    historyList.clear();

    QuerySnapshot qs = await history.get();

    for (int i = 0; i < qs.docs.length; i++) {
      DocumentSnapshot doc = qs.docs[i];
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      historyList.add(
        History(
          data['ordersH'],
          data['timeH'],
          (data['totalpH'] as num).toDouble(),
          data['dineinH'],
          data['ordernumH'],
          data['review'] ?? '',
          data['customerId'] ?? '',
        ),
      );
    }
  }

  static History gethistoryat(int index) {
    return (historyList[index]);
  }

  static Future<void> getHistoryByDate(DateTime date) async {
    historyList.clear();

    DateTime startOfDay = DateTime(date.year, date.month, date.day);
    DateTime endOfDay = startOfDay.add(const Duration(days: 1));

    QuerySnapshot qs = await history
        .where('timeH', isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .where('timeH', isLessThan: Timestamp.fromDate(endOfDay))
        .get();

    for (var doc in qs.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

      historyList.add(
        History(
          data['ordersH'],
          data['timeH'],
          (data['totalpH'] as num).toDouble(),
          data['dineinH'],
          data['ordernumH'],
          data['review'] ?? '',
          data['customerId'] ?? '',
        ),
      );
    }
  }
}
//this.ordersL, this.time, this.totalp,this.dinein,this.ordernum