import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';

import 'resetpassword.dart';
import 'createaccount.dart';
import 'customer_service.dart';
import 'cart_service.dart';

class CustSignInScreen extends StatefulWidget {
  const CustSignInScreen({super.key});

  @override
  State<CustSignInScreen> createState() => _CustSignInScreenState();
}

class _CustSignInScreenState extends State<CustSignInScreen> {
  bool _showPassword = false;
  bool _loading = false;
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool get _isFormFilled =>
      _emailController.text.trim().isNotEmpty && _passwordController.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    _emailController.addListener(() => setState(() {}));
    _passwordController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _signIn() async {
    setState(() => _loading = true);
    bool success = await CustomerService.instance.login(
      _emailController.text,
      _passwordController.text,
    );
    if (success) {
      await CartService.instance.loadOrderHistoryFromFirestore();
    }
    setState(() => _loading = false);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? 'Signed in successfully!' : 'Incorrect email or password')),
    );
    if (success) {
      Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            TextButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.chevron_left, color: Colors.grey),
              label: const Text('Back', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: kOrange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.person_outline, color: kOrange, size: 32),
            ),
            const SizedBox(height: 20),
            const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('Sign in to your customer account', style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 28),
            const Text('EMAIL ADDRESS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                hintText: 'you@email.com',
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: const Icon(Icons.email_outlined),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            const Text('PASSWORD', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
            const SizedBox(height: 8),
            TextField(
              controller: _passwordController,
              obscureText: !_showPassword,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.grey.shade100,
                suffixIcon: IconButton(
                  icon: Icon(_showPassword ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _showPassword = !_showPassword),
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ResetPasswordScreen(isHawker: false)),
                ),
                child: const Text('Forgot password?', style: TextStyle(color: kOrange, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 56,
              child: ElevatedButton(
                onPressed: (_isFormFilled && !_loading) ? _signIn : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isFormFilled ? kOrange : kOrange.withOpacity(0.5),
                  disabledBackgroundColor: kOrange.withOpacity(0.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _loading
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Sign In', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('New here? ', style: TextStyle(color: Colors.grey.shade600)),
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const CreateAccountScreen()),
                  ),
                  child: const Text('Create an account', style: TextStyle(color: kOrange, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ],
        ),
    );
  }
}