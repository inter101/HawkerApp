import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/orderC.dart';


class Historywidget extends StatefulWidget {
  final History history;
  const Historywidget(this.history, {super.key});

  @override
  State<Historywidget> createState() => _HistorywidgetState();
}

class _HistorywidgetState extends State<Historywidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          border: Border.all(color: kOrange, width: 2),
          borderRadius: BorderRadius.circular(25),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row
            Row(
              children: [
                const Icon(
                  Icons.check_circle_outline,
                  size: 22,
                  color: Colors.black,
                ),

                const SizedBox(width: 8),

                Text(
                  '#${widget.history.ordernumH}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),

                const SizedBox(width: 8),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFE8D4),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    (widget.history.dineinH) ? 'Dine in' : "Takeaway",
                    style: TextStyle(
                      color: kOrange,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const Spacer(),

                Text(
                  '\$${widget.history.totalpH}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(width: 5),
              ],
            ),

            const SizedBox(height: 5),

            // Food item
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 5, 0, 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: widget.history.ordersH.map((item) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        item.toString(),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 4),

            // Time/status row
            Row(
              children: [
                const Icon(Icons.access_time, size: 18, color: Colors.grey),

                const SizedBox(width: 4),

                Text(
                  'Completed at ${widget.history.timeH.toDate().toString()}',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
