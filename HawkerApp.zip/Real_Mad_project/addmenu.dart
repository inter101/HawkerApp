import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';

class additem extends StatefulWidget {
  final VoidCallback onCancel;
  const additem({super.key, required this.onCancel});

  @override
  State<additem> createState() => _additemState();
}

class _additemState extends State<additem> {
  String selectedtype = 'Mains';
  var qwe = 0;
  void fun() {}

  TextEditingController tc1 = TextEditingController();
  TextEditingController tc2 = TextEditingController();
  TextEditingController tc3 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100000,
      color: Colors.white,
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 15),
            Text(
              'Add menu dish',
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey),
            ),
            SizedBox(height: 5),
            Container(
              padding: EdgeInsets.fromLTRB(20, 5, 20, 30),
              width: double.infinity,

              decoration: BoxDecoration(
                border: Border.all(color: kOrange, width: 2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('New dish'),
                  SizedBox(height: 8),
                  Text('Add image of dish'),
                  SizedBox(height: 5),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.fromLTRB(0, 0, 75, 0),
                    child: TextField(
                      controller: tc3,
                      keyboardType: TextInputType.numberWithOptions(),
                      decoration: InputDecoration(
                        labelText: 'Enter The image link',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 8),
                  Text('Dish Name'),
                  SizedBox(height: 5),
                  Container(
                    padding: EdgeInsets.fromLTRB(0, 0, 75, 0),
                    child: TextField(
                      controller: tc1,
                      decoration: InputDecoration(
                        labelText: 'Enter Dish Name',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text('Price'),
                  SizedBox(height: 5),
                  Container(
                    padding: EdgeInsets.fromLTRB(0, 0, 75, 0),
                    child: TextField(
                      controller: tc2,
                      keyboardType: TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                          RegExp(r'^\d*\.?\d*'),
                        ),
                      ],
                      decoration: InputDecoration(
                        labelText: 'Enter The Price',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text('Type'),
                  SizedBox(height: 5),
                  SingleChildScrollView(
                    child: DropdownMenu<String>(
                      initialSelection: selectedtype,
                      inputDecorationTheme: InputDecorationTheme(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                          borderSide: const BorderSide(
                            color: Colors.black,
                            width: 1.5,
                          ),
                        ),

                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                          borderSide: const BorderSide(
                            color: Colors.black,
                            width: 1.5,
                          ),
                        ),
                      ),

                      menuStyle: MenuStyle(
                        shape: WidgetStatePropertyAll(
                          RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                      alignmentOffset: const Offset(0, 10),
                      dropdownMenuEntries: [
                        DropdownMenuEntry(value: 'Mains', label: "Mains"),
                        DropdownMenuEntry(value: 'Add-ons', label: "Add-Ons"),
                        DropdownMenuEntry(value: 'Sides', label: "Sides"),
                        DropdownMenuEntry(value: 'Drinks', label: "Drinks"),
                      ],
                      onSelected: (String? value) {
                        if (value != null) {
                          setState(() {
                            selectedtype = value;
                          });
                        }
                      },
                    ),
                  ),
                  SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () async {
                          var price = double.parse(tc2.text.trim());
                          await databaseservice.addMenuItem(
                            tc1.text.trim(),
                            price,
                            selectedtype,
                            tc3.text,
                            true,
                          );
                          setState(() {});
                          widget.onCancel();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kOrange,
                        ),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(width: 12),

                              Text(
                                ' ADD ',

                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                ),
                              ),
                              SizedBox(width: 12),
                            ],
                          ),
                        ),
                      ),
                      Spacer(),
                      ElevatedButton(
                        onPressed: () async {
                          setState(() {});
                          widget.onCancel();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          side: BorderSide(color: Colors.grey, width: 2),
                        ),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(width: 2.5),

                              Text(
                                'CANCEL',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                ),
                              ),
                              SizedBox(width: 2.5),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
