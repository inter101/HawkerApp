import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/customer_service.dart';


/// The little "★ N pts" pill, shown wherever a screen has a top bar so the
/// customer's points balance is always visible.
///
/// Uses [CartService.totalPoints], which already falls back to a
/// session-only counter for guests, so it works whether or not someone is
/// logged in. Wrap sites don't need to worry about that logic.
///
/// Set [onDark] to true when placing this on top of the orange header
/// background (it switches to a translucent-white pill instead of the
/// light-orange one used on white app bars).
class PointsBadge extends StatelessWidget {
  const PointsBadge({super.key, this.onDark = false});

  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([CustomerService.instance, CartService.instance]),
      builder: (context, _) {
        final points = CartService.instance.totalPoints;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: onDark
                ? Colors.white.withValues(alpha: 0.25)
                : const Color.fromRGBO(255, 238, 215, 1),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.star,
                size: 14,
                color: onDark ? Colors.amber : const Color.fromRGBO(243, 129, 27, 1),
              ),
              const SizedBox(width: 6),
              Text(
                '$points pts',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: onDark ? Colors.white : Colors.black87,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}