import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

/// Loads either a network URL, a gs:// Storage URI, or a Firebase
/// Storage object path. This uses the Firebase Storage SDK to get the
/// correct download URL at runtime instead of building a fragile manual
/// URL string.
class FirebaseImage extends StatelessWidget {
  const FirebaseImage(this.path, {super.key, this.width, this.height, this.fit});

  final String? path;
  final double? width;
  final double? height;
  final BoxFit? fit;

  @override
  Widget build(BuildContext context) {
    final p = path?.trim() ?? '';
    if (p.isEmpty) return _placeholder();
    if (p.startsWith('http')) {
      return Image.network(p, width: width, height: height, fit: fit, errorBuilder: (context, error, stackTrace) => _placeholder());
    }
    if (p.startsWith('gs://')) {
      return FutureBuilder<String>(
        future: FirebaseStorage.instance.refFromURL(p).getDownloadURL(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return _placeholder();
          }
          if (snapshot.hasError || snapshot.data == null) {
            return _placeholder();
          }
          return Image.network(snapshot.data!, width: width, height: height, fit: fit, errorBuilder: (context, error, stackTrace) => _placeholder());
        },
      );
    }

    return FutureBuilder<String>(
      future: FirebaseStorage.instance.ref(p).getDownloadURL(),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return _placeholder();
        }
        if (snapshot.hasError || snapshot.data == null) {
          return _placeholder();
        }
        return Image.network(snapshot.data!, width: width, height: height, fit: fit, errorBuilder: (context, error, stackTrace) => _placeholder());
      },
    );
  }

  Widget _placeholder() {
    return Container(
      width: width,
      height: height,
      color: Colors.grey.shade200,
      child: const Icon(Icons.image_not_supported, color: Colors.black26),
    );
  }
}
