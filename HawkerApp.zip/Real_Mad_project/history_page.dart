import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/app_bottom_nav.dart';
import 'package:flutter_application_1/Real_Mad_project/cart_service.dart';
import 'package:flutter_application_1/Real_Mad_project/notification_service.dart';
import 'package:flutter_application_1/Real_Mad_project/points_badge.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  final CartService cartService = CartService.instance;
  StreamSubscription? _historySubscription;

  // One Firestore listener per active order.
  final Map<String, StreamSubscription> _subscriptions = {};

  // Prevent duplicate "order ready" notifications.
  final Set<String> _notifiedOrderIds = {};

  @override
  void initState() {
    super.initState();
    _linkHistoryToFirebase();
  }

  @override
  void dispose() {
    _historySubscription?.cancel();
    for (final sub in _subscriptions.values) {
      sub.cancel();
    }
    super.dispose();
  }

  bool _isOrderDone(Map<String, dynamic> data) {
    final dynamic raw =
        data['status'] ??
        data['orderStatus'] ??
        data['served'] ??
        data['done'] ??
        data['statusH'];
    if (raw is bool) return raw;
    if (raw is num) return raw > 0;
    final value = raw?.toString().trim().toLowerCase() ?? '';
    return value == 'done' ||
        value == 'served' ||
        value == 'completed' ||
        value == 'complete' ||
        value == 'true';
  }

  Future<void> _linkHistoryToFirebase() async {
    await cartService.loadOrderHistoryFromFirestore();
    if (!mounted) return;
    setState(() {});
    _listenToActiveOrders();

    _historySubscription = cartService.watchOrderHistory().listen((_) async {
      await cartService.loadOrderHistoryFromFirestore();
      if (!mounted) return;
      setState(() {});
      _listenToActiveOrders();
    });
  }

  void _listenToActiveOrders() {
    for (final order in cartService.orders) {
      _watchOrder(order);
    }
  }

  void _watchOrder(CartOrder order) {
    if (order.isServed) return; // already done, nothing to watch
    if (_subscriptions.containsKey(order.orderId)) return; // already watching

    final sub = cartService
        .watchOrder(order.orderId, stallDocId: order.stallDocId)
        .listen((snapshot) {
          final data = snapshot.data();
          if (data == null) return;

          if (_isOrderDone(data) && !order.isServed) {
            setState(() {
              order.status = 'served';
            });

            if (!_notifiedOrderIds.contains(order.orderId)) {
              _notifiedOrderIds.add(order.orderId);
              NotificationService.instance.showOrderReadyNotification(
                dinein: order.dinein,
              );
            }

            _subscriptions[order.orderId]?.cancel();
            _subscriptions.remove(order.orderId);
          }
        });

    _subscriptions[order.orderId] = sub;
  }

  @override
  Widget build(BuildContext context) {
    // Keep listeners attached for newly placed orders.
    _listenToActiveOrders();

    final currentOrders = cartService.orders.where((o) => !o.isServed).toList();
    final pastOrders = cartService.orders.where((o) => o.isServed).toList();

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: cartService.orders.isEmpty
            ? _buildEmptyState(context)
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildHeader(),
                      const SizedBox(height: 25),
                      if (currentOrders.isNotEmpty) ...[
                        const Text(
                          'Current Orders',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        for (final order in currentOrders)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 16),
                            child: _buildCurrentOrderCard(order),
                          ),
                        const SizedBox(height: 10),
                      ],
                      if (pastOrders.isNotEmpty) ...[
                        const Text(
                          'Past Orders',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        for (final order in pastOrders)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 16),
                            child: _buildPastOrderCard(order),
                          ),
                      ],
                    ],
                  ),
                ),
              ),
      ),
      bottomNavigationBar: buildAppBottomNav(context, 3),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(4, 10, 4, 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: const [
          Expanded(
            child: Text(
              'Order History',
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ),
          PointsBadge(),
        ],
      ),
    );
  }

  Widget _buildCurrentOrderCard(CartOrder order) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => _showOrderDetailsDialog(order),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: const Color.fromRGBO(243, 129, 27, 1),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _dishIcon(),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          order.title,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          order.subtitle,
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    order.amount,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color.fromRGBO(243, 129, 27, 1),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              const Divider(height: 1),
              const SizedBox(height: 14),
              Row(
                children: [
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'Preparing',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showOrderDetailsDialog(CartOrder order) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(order.title),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  _detailRow('Order ID', order.orderId),
                  _detailRow('Order No.', '#${order.orderNumber}'),
                  _detailRow('Stall', order.stallName),
                  _detailRow(
                    'Stall No.',
                    order.stallNumber.trim().isNotEmpty
                        ? order.stallNumber
                        : '-',
                  ),
                  _detailRow('Type', order.dinein ? 'Dine In' : 'Takeaway'),
                  _detailRow('Status', order.status),
                  _detailRow(
                    'Date',
                    '${order.date.day}/${order.date.month}/${order.date.year}',
                  ),
                  _detailRow('Total', order.amount),
                  if (order.comment.trim().isNotEmpty) ...[
                    const SizedBox(height: 12),
                    const Text(
                      'Comment',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    Text(order.comment),
                  ],
                  const SizedBox(height: 12),
                  const Text(
                    'Items',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  for (final dish in order.dishNames)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text('• $dish'),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.black54,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  Widget _buildPastOrderCard(CartOrder order) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          _dishIcon(),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${order.date.day}/${order.date.month}/${order.date.year}',
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
                const SizedBox(height: 4),
                Text(
                  order.title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  order.subtitle,
                  style: const TextStyle(fontSize: 13, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Served',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade800,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text(
            order.amount,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _dishIcon() {
    return Container(
      width: 55,
      height: 55,
      decoration: BoxDecoration(
        color: Colors.orange.shade100,
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Icon(Icons.fastfood, color: Colors.black87, size: 28),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 40, 20, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Order History',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Review your previous orders and re-order anytime.',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 25),
            Center(
              child: Column(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: const Color.fromRGBO(255, 238, 215, 1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.access_time_outlined,
                      size: 60,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 25),
                  const Text(
                    'No orders yet',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Browse dishes and place your first order.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromRGBO(243, 129, 27, 1),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        elevation: 5,
                      ),
                      onPressed: () {
                        Navigator.pushReplacementNamed(context, '/home');
                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: Text(
                          'Browse Dishes',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
