import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';


import 'custfirebase.dart';


class ResettingPasswordScreen extends StatefulWidget {
  final String email;
  final bool isHawker;
  const ResettingPasswordScreen({super.key, required this.email, required this.isHawker});

  @override
  State<ResettingPasswordScreen> createState() => _ResettingPasswordScreenState();
}

class _ResettingPasswordScreenState extends State<ResettingPasswordScreen> {
  final _passwordController = TextEditingController();
  bool _showPassword = false;
  bool _loading = false;

  bool get _isFormFilled => _passwordController.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    _passwordController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _savePassword() async {
    setState(() => _loading = true);
    if (widget.isHawker) {
      await databaseservice.updateHawkerPassword(widget.email, _passwordController.text);
    } else {
      await Custfirebase.updateCustomerPassword(widget.email, _passwordController.text);
    }
    setState(() => _loading = false);
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Password updated! Please sign in.')),
    );
    Navigator.popUntil(context, (route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.chevron_left, color: Colors.grey),
            label: const Text('Back', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 16),
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: kOrange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.lock_reset, color: kOrange, size: 32),
          ),
          const SizedBox(height: 20),
          const Text('Set New Password', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('Choose a new password for ${widget.email}', style: TextStyle(color: Colors.grey.shade600)),
          const SizedBox(height: 28),
          const Text('NEW PASSWORD', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey)),
          const SizedBox(height: 8),
          TextField(
            controller: _passwordController,
            obscureText: !_showPassword,
            decoration: InputDecoration(
              hintText: 'At least 6 characters',
              filled: true,
              fillColor: Colors.grey.shade100,
              suffixIcon: IconButton(
                icon: Icon(_showPassword ? Icons.visibility_off : Icons.visibility),
                onPressed: () => setState(() => _showPassword = !_showPassword),
              ),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 56,
            child: ElevatedButton(
              onPressed: (_isFormFilled && !_loading) ? _savePassword : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: _isFormFilled ? kOrange : kOrange.withOpacity(0.5),
                disabledBackgroundColor: kOrange.withOpacity(0.5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: _loading
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Save Password', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}