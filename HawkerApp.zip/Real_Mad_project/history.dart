import 'package:flutter/material.dart';
import 'package:flutter_application_1/Real_Mad_project/aiclass.dart';
import 'package:flutter_application_1/Real_Mad_project/calendar.dart';
import 'package:flutter_application_1/Real_Mad_project/database.dart';
import 'package:flutter_application_1/Real_Mad_project/historywidget.dart';
import 'package:flutter_application_1/Real_Mad_project/home.dart';
import 'package:flutter_application_1/Real_Mad_project/orderC.dart';
import 'package:flutter_application_1/Real_Mad_project/qaz.dart';

class history extends StatefulWidget {
  const history({super.key});

  @override
  State<history> createState() => _historyState();
}

class _historyState extends State<history> {
  @override
  void initState() {
    super.initState();
    loadHistory();
  }

  DateTime selectedDate = DateTime.now();

  Future<void> loadHistory() async {
    await databaseservice.getHistoryByDate(selectedDate);
    setState(() {});
  }

  bool aisloppress = false;
  String aiSummary = "";
  bool hasaialreadybeencalled = false;
  String result = "";
  String prompt = "";
  double get totalRevenue {
    double total = 0;

    for (History h in databaseservice.historyList) {
      total += h.totalpH;
    }

    return total;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: kOrange,
        toolbarHeight: 130,
        surfaceTintColor: Colors.white,
        scrolledUnderElevation: 0,
        elevation: 0,
        title: Row(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  'History',
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                ),

                SizedBox(height: 4),
                Row(
                  children: [
                    SizedBox(width: 8),
                    Text(
                      'Orders History',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: Padding(
            padding: EdgeInsets.fromLTRB(25, 25, 25, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  child: calendarbar(
                    selectedDate: selectedDate,
                    onDateChanged: (newDate) async {
                      setState(() {
                        selectedDate = newDate;
                      });

                      await databaseservice.getHistoryByDate(selectedDate);

                      setState(() {});
                    },
                  ),
                ),
                SizedBox(height: 30),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: kOrange, width: 2),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Revenue',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 5),
                            Text(
                              '\$${totalRevenue.toStringAsFixed(2)}',
                              style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(width: 30),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: kOrange, width: 2),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Total Orders',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 5),

                            Text(
                              '${databaseservice.getorderCount()}',
                              style: TextStyle(
                                fontSize: 25,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 15),

                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    border: Border.all(color: kOrange, width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: GestureDetector(
                    child: Text(
                      (aisloppress)
                          ? ('''
                              AI Summary for  the day
                              ${aiSummary}''')
                          : "Get an Ai summary of the reviews",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onTap: () async {
                      if (hasaialreadybeencalled) {
                        aiSummary = result;
                      } else {
                        setState(() {
                          aiSummary = "Generating AI summary...";
                          aisloppress = true;
                        });
                        StringBuffer data = StringBuffer();

                        data.writeln(
                          "Analyse today's sales for ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}",
                        );

                        for (
                          int i = 0;
                          i < databaseservice.gethistoryCount();
                          i++
                        ) {
                          History h = databaseservice.gethistoryat(i);

                          data.writeln("""
                          Order number: ${h.ordernumH}
                          Items: ${h.ordersH}
                          Total price: \$${h.totalpH}
                          Dine in: ${h.dineinH}
                          Review: ${h.review}
                          """);
                        }

                        data.writeln("""
                        Based on these orders:

                        1. Identify the most popular dish.
                        2. Compare the average revenue of the selected day to the average amount made across days where at least one order have been completed     
                        3. Summarise customer reviews.
                        4. Give suggestions to improve the stall.
                        5. Please keep the response to only 6-7 lines
                   
                        """);

                        prompt = data.toString();
                      }

                      try {
                        result = await GeminiService.askGemini(prompt);
                      } catch (e) {
                        print("Gemini error: $e");
                        result = "AI failed: $e";
                      }
                      setState(() {
                        aiSummary = result;
                        hasaialreadybeencalled = true;
                      });
                    },
                  ),
                ),

                SizedBox(height: 25),
                Container(
                  child: Text(
                    'All Order',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(height: 5),
                Container(
                  child: (databaseservice.gethistoryCount() == 0)
                      ? Container(
                          alignment: Alignment.center,
                          padding: EdgeInsets.fromLTRB(0, 10, 0, 150),
                          child: Text(
                            "No orders for this date",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey,
                            ),
                          ),
                        )
                      : Column(
                          children: List.generate(
                            databaseservice.gethistoryCount(),
                            (index) => Historywidget(
                              databaseservice.gethistoryat(index),
                            ),
                          ),
                        ),
                ),
                SizedBox(height: 75),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: qaz(),
    );
  }
}
